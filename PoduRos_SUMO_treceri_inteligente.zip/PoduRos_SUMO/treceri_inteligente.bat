@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py -3 treceri_inteligente\smart_gui.py %*) else (python treceri_inteligente\smart_gui.py %*)
if errorlevel 1 pause

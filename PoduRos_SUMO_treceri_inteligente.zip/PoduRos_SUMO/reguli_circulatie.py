# -*- coding: utf-8 -*-
"""
REGULILE DE CIRCULATIE DIN ROMANIA aplicate in simulare
(OUG 195/2002 privind circulatia pe drumurile publice + Regulamentul de aplicare HG 1391/2006,
 modificat prin HG 130/2023).

Ce se respecta si cum e modelat in SUMO:
  * Viteza: maxim limita strazii (50 km/h in localitate daca nu e semnalizat altfel) - art. 49 OUG.
      -> speedFactor <= 1.0 (nimeni nu depaseste limita), vehiculele de urgenta sunt exceptate.
  * Semafor: pe rosu nu trece nimeni, pe galben opreste daca poate - art. 52 Regulament.
      -> jmDriveAfterRedTime=-1, jmDriveAfterYellowTime=-1; fara "dreapta pe rosu" (doar sageata verde).
  * Prioritate: cine vine de pe drumul secundar cedeaza; la intersectii nesemnalizate intre strazi
    egale -> prioritate de dreapta (art. 57 OUG); iesirea din curti/parcari cedeaza (strazile de serviciu
    au prioritate mica).  -> tipul nodurilor (priority / right_before_left), impatience=0.
  * Sens giratoriu: cine e in giratoriu are prioritate, cine intra cedeaza; banda 1 (exterioara)
    are prioritate la iesire (HG 130/2023).  -> netconvert --roundabouts.guess + verificare.
  * Tramvaiul are prioritate in intersectiile nedirijate (art. 59 OUG); masinile nu circula pe calea
    de rulare separata si nu opresc pe sine.  -> prioritatea caii de rulare > prioritatea strazii.
  * Pietonii au prioritate pe trecerile nesemaforizate (art. 72 OUG, art. 135 Regulament);
    la semafor trec doar pe verde; traverseaza doar pe treceri.  -> crossing priority="true".
  * Nu intri in intersectie / pe trecere / pe sine daca nu ai loc sa iesi (art. 128 Regulament).
      -> keepClear respectat (jmIgnoreKeepClearTime=-1).
  * Distanta fata de vehiculul din fata (art. 51 OUG) -> tau >= 1.0 s, minGap >= 1.5 m.
  * Mers pe banda din dreapta, depasire doar pe stanga, fara schimbare de banda in intersectie
    (art. 45 OUG, art. 120 Regulament) -> lcKeepRight, SUMO nu schimba banda in intersectie.
  * Vehiculele de urgenta cu girofar si sirena au prioritate (art. 32 si 61 OUG): pot trece pe rosu
    cu prudenta, celelalte vehicule le fac loc (culoar de urgenta).  -> device.bluelight.

Pune RESPECTA_REGULILE = False ca sa revii la soferii "nervosi" din versiunea veche
(impatience, intra in intersectii blocate, depasesc viteza).
"""
from __future__ import print_function
import os
import re
import random

RESPECTA_REGULILE = True

# vehicule de urgenta pe ora pentru fiecare nivel de trafic
URGENTE_H = {"liber": 2, "relativ_liber": 3, "semi_aglomerat": 4, "aglomerat": 5, "ora_de_varf": 6, "ambuteiaj": 6}

# optiuni netconvert: trotuare mai late (3 m) -> pietonii nu se mai blocheaza la treceri
# (prioritatea de dreapta ramane doar la intersectiile dintre strazi mici, ca in realitate)
NETCONVERT_OPTS = ["--default.sidewalk-width", "3.0"]

# culoar de urgenta cu modelul "sublane": mai lent si poate produce suprapuneri -> oprit implicit
CULOAR_URGENTA = False
SUMO_OPTS_XML = ['        <lateral-resolution value="0.8"/>'] if CULOAR_URGENTA else []


def _cap_speed(dist):
    """normc(medie, abatere, min, max) -> nimeni peste limita legala (max 1.0)"""
    m = re.match(r"normc\(([\d.]+),([\d.]+),([\d.]+),([\d.]+)\)", dist.replace(" ", ""))
    if not m:
        return dist
    mean, dev, lo, hi = [float(v) for v in m.groups()]
    return "normc(%.2f,%.2f,%.2f,1.00)" % (min(mean, 0.95), min(dev, 0.08), lo)


def atribute_masina(P):
    """atributele vType pentru soferi, pentru nivelul P (dict din NIVELURI)"""
    if not RESPECTA_REGULILE:
        kc = ' jmIgnoreKeepClearTime="%d"' % P["keepClear"] if P["keepClear"] >= 0 else ""
        return ('speedFactor="%s" sigma="%.2f" tau="%.2f" minGap="%.2f" impatience="%.2f" lcCooperative="%.2f"%s'
                % (P["speedFactor"], P["sigma"], P["tau"], P["minGap"], P["impatience"],
                   max(0.3, 1.0 - P["impatience"] * 0.6), kc))
    return ('speedFactor="%s" sigma="%.2f" tau="%.2f" minGap="%.2f" impatience="0.00" lcCooperative="1.00" '
            'lcKeepRight="1.0" lcSpeedGain="0.8" jmDriveAfterRedTime="-1" jmDriveAfterYellowTime="-1" '
            'jmIgnoreKeepClearTime="-1" jmIgnoreFoeProb="0" jmCrossingGap="10"'
            % (_cap_speed(P["speedFactor"]), P["sigma"], max(1.0, P["tau"]), max(1.5, P["minGap"])))


def teleport(P, verificat=False):
    """scenariile verificate (fara niciun blocaj in test) -> teleportarea e oprita complet (-1)"""
    if verificat:
        return -1
    if RESPECTA_REGULILE and P["teleport"] < 0:
        return 900
    return P["teleport"]


_BLUE = '        <param key="has.bluelight.device" value="true"/>\n' if CULOAR_URGENTA else ''
_URG = ('accel="2.8" decel="4.5" emergencyDecel="7.0" sigma="0.2" impatience="1.0" '
        'jmDriveAfterRedTime="300" jmDriveRedSpeed="5.56" jmIgnoreFoeProb="0" '
        'lcCooperative="0.5" lcAssertive="2"')
TIPURI_URGENTA = [
    # id, pondere, atribute
    ("ambulanta", 0.60, 'vClass="emergency" guiShape="emergency" color="250,250,250" length="6.5" minGap="2.5" speedFactor="1.30" '),
    ("politie", 0.25, 'vClass="emergency" guiShape="police" color="30,70,220" length="4.8" minGap="2.0" speedFactor="1.35" '),
    ("pompieri", 0.15, 'vClass="emergency" guiShape="firebrigade" color="220,25,25" length="9.0" minGap="3.0" speedFactor="1.20" '),
]


def vtypes_urgenta_xml(trece_pe_rosu=True):
    o = []
    urg = _URG if trece_pe_rosu else _URG.replace('jmDriveAfterRedTime="300"', 'jmDriveAfterRedTime="-1"')
    for tid, _, attrs in TIPURI_URGENTA:
        o.append('    <vType id="%s" %s%s>\n%s    </vType>' % (tid, attrs, urg, _BLUE))
    return "\n".join(o)


def scrie_tipuri_urgenta(path, trece_pe_rosu=True):
    with open(path, "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<additional>\n'
                '    <!-- vehicule de urgenta cu girofar si sirena (art. 32 OUG 195/2002) -->\n'
                + vtypes_urgenta_xml(trece_pe_rosu) + '\n</additional>\n')


def alege_tip(rnd):
    x = rnd.random()
    for tid, w, _ in TIPURI_URGENTA:
        if x < w:
            return tid
        x -= w
    return TIPURI_URGENTA[0][0]


def perechi_din_trips(path):
    if not os.path.isfile(path):
        return []
    txt = open(path, encoding="utf-8").read()
    return sorted(set(re.findall(r'<trip [^>]*from="([^"]+)" to="([^"]+)"', txt)))


def scrie_urgente(path, perechi, pe_ora, durata, seed):
    """calatorii de urgenta (proces Poisson) intre intrarile/iesirile folosite de masini"""
    rnd = random.Random(seed)
    o = ['<?xml version="1.0" encoding="UTF-8"?>', '<routes>']
    t, i = 0.0, 0
    if perechi and pe_ora > 0:
        t = rnd.expovariate(pe_ora / 3600.0)
        while t < durata:
            f, to = rnd.choice(perechi)
            o.append('    <trip id="urgenta_%d" type="%s" depart="%.2f" from="%s" to="%s" departLane="best" departSpeed="max"/>'
                     % (i, alege_tip(rnd), t, f, to))
            i += 1
            t += rnd.expovariate(pe_ora / 3600.0)
    o += ['</routes>', '']
    with open(path, "w", encoding="utf-8") as fo:
        fo.write("\n".join(o))
    return i

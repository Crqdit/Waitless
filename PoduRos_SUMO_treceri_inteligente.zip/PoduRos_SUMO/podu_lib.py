# -*- coding: utf-8 -*-
"""Functii comune pentru proiectul SUMO - Rondul Podu Ros (Iasi)."""
from __future__ import print_function
import os, sys, math, glob, shutil
import xml.etree.ElementTree as ET
from collections import OrderedDict

ROOT = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------------------
#  NIVELURI DE TRAFIC  (le poti modifica aici, apoi rulezi din nou construieste)
#  masini_h   = vehicule / ora intrate in retea
#  pietoni_h  = pietoni / ora
#  tram_interval = secunde intre doua tramvaie ale ACELEIASI linii
#  tram_stationare = secunde de stationare in statie
# ---------------------------------------------------------------------------
NIVELURI = OrderedDict([
    ("liber", dict(
        nume="Liber", masini_h=350, pietoni_h=120, tram_interval=900, tram_stationare=15,
        speedFactor="normc(1.05,0.10,0.6,1.5)", sigma=0.4, tau=1.0, minGap=2.5, impatience=0.0,
        keepClear=-1, ped_speed="normc(1.05,0.10,0.6,1.5)", teleport=300)),
    ("relativ_liber", dict(
        nume="Relativ liber", masini_h=800, pietoni_h=350, tram_interval=720, tram_stationare=20,
        speedFactor="normc(1.00,0.10,0.6,1.5)", sigma=0.5, tau=1.0, minGap=2.5, impatience=0.0,
        keepClear=-1, ped_speed="normc(1.00,0.10,0.6,1.4)", teleport=300)),
    ("semi_aglomerat", dict(
        nume="Semi-aglomerat", masini_h=1400, pietoni_h=700, tram_interval=600, tram_stationare=25,
        speedFactor="normc(0.97,0.10,0.6,1.4)", sigma=0.5, tau=1.05, minGap=2.3, impatience=0.1,
        keepClear=-1, ped_speed="normc(0.97,0.10,0.6,1.4)", teleport=300)),
    ("aglomerat", dict(
        nume="Aglomerat", masini_h=2100, pietoni_h=1200, tram_interval=480, tram_stationare=35,
        speedFactor="normc(0.93,0.10,0.5,1.3)", sigma=0.6, tau=1.1, minGap=2.0, impatience=0.3,
        keepClear=-1, ped_speed="normc(0.92,0.10,0.5,1.3)", teleport=400)),
    ("ora_de_varf", dict(
        nume="Ora de varf", masini_h=2900, pietoni_h=1900, tram_interval=360, tram_stationare=45,
        speedFactor="normc(0.90,0.10,0.5,1.3)", sigma=0.6, tau=1.15, minGap=1.8, impatience=0.5,
        keepClear=-1, ped_speed="normc(0.88,0.10,0.5,1.2)", teleport=600)),
    ("ambuteiaj", dict(
        nume="Ambuteiaj", masini_h=4200, pietoni_h=2600, tram_interval=300, tram_stationare=60,
        speedFactor="normc(0.85,0.10,0.4,1.2)", sigma=0.7, tau=1.3, minGap=1.5, impatience=0.8,
        keepClear=5, ped_speed="normc(0.80,0.10,0.4,1.1)", teleport=-1)),
])
DURATA = 3600      # secunde de cerere de trafic generata
SIM_END = 4200     # cand se opreste simularea

DIR_RETEA = os.path.join(ROOT, "retea")
DIR_TRAFIC = os.path.join(ROOT, "trafic")
DIR_SCEN = os.path.join(ROOT, "scenarii")
DIR_GUI = os.path.join(ROOT, "gui")
DIR_SAT = os.path.join(ROOT, "satelit")
DIR_REZ = os.path.join(ROOT, "rezultate")
NET = os.path.join(DIR_RETEA, "podu_ros.net.xml")
OSM = os.path.join(ROOT, "map.osm")


# ---------------------------------------------------------------------------
#  SUMO
# ---------------------------------------------------------------------------
def sumo_home():
    cands = []
    if os.environ.get("SUMO_HOME"):
        cands.append(os.environ["SUMO_HOME"])
    try:
        import sumo  # pachetul pip eclipse-sumo
        cands.append(sumo.SUMO_HOME)
    except Exception:
        pass
    cands += glob.glob(r"C:\Program Files*\Eclipse\Sumo*") + glob.glob(r"C:\Program Files*\Sumo*")
    cands += ["/usr/share/sumo", "/usr/local/share/sumo", "/opt/homebrew/share/sumo"]
    for c in cands:
        if c and os.path.isdir(os.path.join(c, "tools")):
            return c
    return None


def binary(name):
    home = sumo_home()
    exe = name + (".exe" if os.name == "nt" else "")
    if home:
        p = os.path.join(home, "bin", exe)
        if os.path.isfile(p):
            return p
    p = shutil.which(name)
    if p:
        return p
    raise RuntimeError("Nu gasesc '%s'. Instaleaza SUMO si seteaza variabila SUMO_HOME." % name)


def tool(name):
    home = sumo_home()
    if home:
        for sub in ("", "route", "net"):
            p = os.path.join(home, "tools", sub, name)
            if os.path.isfile(p):
                return p
    return None


# ---------------------------------------------------------------------------
#  Proiectie UTM (WGS84) - identica cu cea folosita de netconvert
# ---------------------------------------------------------------------------
def utm(lat, lon, zone):
    a = 6378137.0; f = 1 / 298.257223563; k0 = 0.9996
    e2 = f * (2 - f); ep2 = e2 / (1 - e2)
    lat = math.radians(lat); lon0 = math.radians((zone - 1) * 6 - 180 + 3); lon = math.radians(lon)
    N = a / math.sqrt(1 - e2 * math.sin(lat) ** 2); T = math.tan(lat) ** 2
    C = ep2 * math.cos(lat) ** 2; A = math.cos(lat) * (lon - lon0)
    M = a * ((1 - e2 / 4 - 3 * e2 ** 2 / 64 - 5 * e2 ** 3 / 256) * lat
             - (3 * e2 / 8 + 3 * e2 ** 2 / 32 + 45 * e2 ** 3 / 1024) * math.sin(2 * lat)
             + (15 * e2 ** 2 / 256 + 45 * e2 ** 3 / 1024) * math.sin(4 * lat)
             - (35 * e2 ** 3 / 3072) * math.sin(6 * lat))
    x = k0 * N * (A + (1 - T + C) * A ** 3 / 6 + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * A ** 5 / 120) + 500000
    y = k0 * (M + N * math.tan(lat) * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A ** 4 / 24
                                       + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * A ** 6 / 720))
    return x, y


def utm_inv(x, y, zone):
    a = 6378137.0; f = 1 / 298.257223563; k0 = 0.9996
    e2 = f * (2 - f); ep2 = e2 / (1 - e2)
    e1 = (1 - math.sqrt(1 - e2)) / (1 + math.sqrt(1 - e2))
    x -= 500000.0
    M = y / k0
    mu = M / (a * (1 - e2 / 4 - 3 * e2 ** 2 / 64 - 5 * e2 ** 3 / 256))
    p1 = (mu + (3 * e1 / 2 - 27 * e1 ** 3 / 32) * math.sin(2 * mu) + (21 * e1 ** 2 / 16 - 55 * e1 ** 4 / 32) * math.sin(4 * mu)
          + (151 * e1 ** 3 / 96) * math.sin(6 * mu) + (1097 * e1 ** 4 / 512) * math.sin(8 * mu))
    N1 = a / math.sqrt(1 - e2 * math.sin(p1) ** 2); T1 = math.tan(p1) ** 2; C1 = ep2 * math.cos(p1) ** 2
    R1 = a * (1 - e2) / (1 - e2 * math.sin(p1) ** 2) ** 1.5; D = x / (N1 * k0)
    lat = p1 - (N1 * math.tan(p1) / R1) * (D * D / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * ep2) * D ** 4 / 24
                                           + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * ep2 - 3 * C1 * C1) * D ** 6 / 720)
    lon = (D - (1 + 2 * T1 + C1) * D ** 3 / 6 + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * ep2 + 24 * T1 * T1) * D ** 5 / 120) / math.cos(p1)
    return math.degrees(lat), (zone - 1) * 6 - 180 + 3 + math.degrees(lon)


# ---------------------------------------------------------------------------
#  Citire retea (fara sumolib, ca sa nu depindem de nimic)
# ---------------------------------------------------------------------------
def parse_shape(s):
    return [tuple(float(v) for v in p.split(",")[:2]) for p in s.split()]


class Net(object):
    def __init__(self, path):
        r = ET.parse(path).getroot()
        loc = r.find("location")
        self.offset = [float(v) for v in loc.get("netOffset").split(",")]
        proj = loc.get("projParameter", "")
        self.zone = 35
        for tok in proj.split():
            if tok.startswith("+zone="):
                self.zone = int(tok[6:])
        self.edges = OrderedDict()     # id -> dict
        self.crossings = []
        for e in r.findall("edge"):
            fn = e.get("function")
            lanes = []
            for l in e.findall("lane"):
                allow = l.get("allow")
                disallow = l.get("disallow")
                lanes.append(dict(id=l.get("id"), length=float(l.get("length")),
                                  width=float(l.get("width", "3.2")), shape=parse_shape(l.get("shape")),
                                  allow=allow.split() if allow is not None else None,
                                  disallow=disallow.split() if disallow is not None else []))
            d = dict(id=e.get("id"), function=fn, frm=e.get("from"), to=e.get("to"), lanes=lanes,
                     name=e.get("name", ""))
            if fn == "crossing":
                d["junction"] = e.get("id")[1:].rsplit("_", 1)[0]
                self.crossings.append(d)
            self.edges[e.get("id")] = d
        self.junctions = {j.get("id"): j.get("type") for j in r.findall("junction")}
        self.jxy = {j.get("id"): (float(j.get("x")), float(j.get("y"))) for j in r.findall("junction")}
        self.succ = {}
        for c in r.findall("connection"):
            self.succ.setdefault(c.get("from"), set()).add(c.get("to"))

    def xy(self, lat, lon):
        x, y = utm(lat, lon, self.zone)
        return x + self.offset[0], y + self.offset[1]

    def lonlat(self, x, y):
        """returneaza (lat, lon)"""
        return utm_inv(x - self.offset[0], y - self.offset[1], self.zone)

    @staticmethod
    def lane_allows(l, vclass):
        if l["allow"] is not None:
            return vclass in l["allow"]
        return vclass not in l["disallow"]

    def edge_allows(self, eid, vclass):
        return any(self.lane_allows(l, vclass) for l in self.edges[eid]["lanes"])

    def normal_edges(self, vclass):
        return [e for e, d in self.edges.items() if not d["function"] and self.edge_allows(e, vclass)]


def dist_point_polyline(p, shape):
    """distanta minima si pozitia de-a lungul poliliniei"""
    best = (1e18, 0.0); acc = 0.0
    for (x1, y1), (x2, y2) in zip(shape[:-1], shape[1:]):
        dx, dy = x2 - x1, y2 - y1; L = math.hypot(dx, dy)
        t = 0.0 if L == 0 else max(0.0, min(1.0, ((p[0] - x1) * dx + (p[1] - y1) * dy) / (L * L)))
        d = math.hypot(x1 + t * dx - p[0], y1 + t * dy - p[1])
        if d < best[0]:
            best = (d, acc + t * L)
        acc += L
    return best


def buffer_polyline(shape, w):
    """poligon (dreptunghi urmand linia) de latime w"""
    h = w / 2.0
    left, right = [], []
    n = len(shape)
    for i in range(n):
        if i == 0:
            dx, dy = shape[1][0] - shape[0][0], shape[1][1] - shape[0][1]
        elif i == n - 1:
            dx, dy = shape[-1][0] - shape[-2][0], shape[-1][1] - shape[-2][1]
        else:
            dx, dy = shape[i + 1][0] - shape[i - 1][0], shape[i + 1][1] - shape[i - 1][1]
        L = math.hypot(dx, dy) or 1.0
        nx, ny = -dy / L * h, dx / L * h
        left.append((shape[i][0] + nx, shape[i][1] + ny))
        right.append((shape[i][0] - nx, shape[i][1] - ny))
    pts = left + right[::-1] + [left[0]]
    return " ".join("%.2f,%.2f" % p for p in pts)


def osm_bounds(path=OSM):
    for ev, el in ET.iterparse(path, events=("start",)):
        if el.tag == "bounds":
            return (float(el.get("minlat")), float(el.get("minlon")),
                    float(el.get("maxlat")), float(el.get("maxlon")))
    raise RuntimeError("map.osm nu are <bounds>")


def write_sumocfg(path, masini, pietoni, tramvaie, scale=1.0, satelit=True):
    """scrie un fisier .sumocfg pentru combinatia de niveluri aleasa"""
    rel = lambda p: os.path.relpath(p, os.path.dirname(path)).replace("\\", "/")
    add = [os.path.join(DIR_TRAFIC, "tipuri_masini_%s.add.xml" % masini),
           os.path.join(DIR_TRAFIC, "tipuri_pietoni_%s.add.xml" % pietoni),
           os.path.join(DIR_TRAFIC, "tipuri_tramvai.add.xml"),
           os.path.join(DIR_TRAFIC, "tipuri_urgenta.add.xml"),
           os.path.join(DIR_RETEA, "statii_tramvai.add.xml"),
           os.path.join(DIR_RETEA, "treceri_pietoni.add.xml")]
    add = [a for a in add if os.path.exists(a)]
    routes = [os.path.join(DIR_TRAFIC, "tramvaie_%s.rou.xml" % tramvaie),
              os.path.join(DIR_TRAFIC, "masini_%s.trips.xml" % masini),
              os.path.join(DIR_TRAFIC, "pietoni_%s.trips.xml" % pietoni),
              os.path.join(DIR_TRAFIC, "urgente_%s.rou.xml" % masini)]
    routes = [r for r in routes if os.path.exists(r)]
    import reguli_circulatie as RC
    import verificare_sim as V
    ver = masini == pietoni == tramvaie and V.verificat(masini) and abs(scale - 1.0) < 1e-9
    tele = RC.teleport(NIVELURI[masini], verificat=ver)
    gui = os.path.join(DIR_GUI, "vizualizare_satelit.settings.xml" if satelit else "vizualizare.settings.xml")
    if not os.path.exists(gui):
        gui = os.path.join(DIR_GUI, "vizualizare.settings.xml")
    tag = "%s_%s_%s" % (masini, pietoni, tramvaie)
    if not os.path.isdir(DIR_REZ):
        os.makedirs(DIR_REZ)
    s = ['<?xml version="1.0" encoding="UTF-8"?>',
         '<!-- Podu Ros - masini: %s | pietoni: %s | tramvaie: %s -->' % (
             NIVELURI[masini]["nume"], NIVELURI[pietoni]["nume"], NIVELURI[tramvaie]["nume"]),
         '<configuration>',
         '    <input>',
         '        <net-file value="%s"/>' % rel(NET),
         '        <additional-files value="%s"/>' % ",".join(rel(a) for a in add),
         '        <route-files value="%s"/>' % ",".join(rel(r) for r in routes),
         '    </input>',
         '    <time>',
         '        <begin value="0"/>',
         '        <end value="%d"/>' % SIM_END,
         '        <step-length value="0.5"/>',
         '    </time>',
         '    <processing>',
         '        <ignore-route-errors value="true"/>',
         '        <time-to-teleport value="%d"/>' % tele,
         '        <pedestrian.model value="striping"/>',
         '        <collision.action value="warn"/>',
         '        <collision.check-junctions value="true"/>',
         '        <scale value="%g"/>' % scale] + RC.SUMO_OPTS_XML + [
         '    </processing>',
         '    <routing>',
         '        <device.rerouting.probability value="0.3"/>',
         '        <device.rerouting.period value="120"/>',
         '    </routing>',
         '    <output>',
         '        <summary-output value="%s"/>' % rel(os.path.join(DIR_REZ, "sumar_%s.xml" % tag)),
         '        <tripinfo-output value="%s"/>' % rel(os.path.join(DIR_REZ, "calatorii_%s.xml" % tag)),
         '    </output>',
         '    <report>',
         '        <no-step-log value="true"/>',
         '        <duration-log.statistics value="true"/>',
         '    </report>',
         '    <gui_only>',
         '        <gui-settings-file value="%s"/>' % rel(gui),
         '    </gui_only>',
         '</configuration>', '']
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(s))
    return path

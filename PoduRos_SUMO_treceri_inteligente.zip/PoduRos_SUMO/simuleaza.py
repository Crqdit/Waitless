# -*- coding: utf-8 -*-
"""
Porneste simularea rondului Podu Ros.

  python simuleaza.py                         -> meniu interactiv
  python simuleaza.py --nivel ora_de_varf     -> acelasi nivel pentru masini, pietoni si tramvaie
  python simuleaza.py --masini ambuteiaj --pietoni liber --tramvaie aglomerat
  optiuni:  --scale 1.3  (inmulteste traficul)   --fara-satelit   --start   --consola (fara interfata)

Niveluri: liber, relativ_liber, semi_aglomerat, aglomerat, ora_de_varf, ambuteiaj
"""
from __future__ import print_function
import os, sys, argparse, subprocess

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from podu_lib import NIVELURI, DIR_SCEN, NET, write_sumocfg, binary

KEYS = list(NIVELURI.keys())


def alege(titlu, implicit=None):
    print("\n" + titlu)
    for i, k in enumerate(KEYS, 1):
        P = NIVELURI[k]
        print("  %d) %-15s (masini %d/h, pietoni %d/h, tramvai la %d min)" % (
            i, P["nume"], P["masini_h"], P["pietoni_h"], round(P["tram_interval"] / 60.0)))
    prompt = "Alege 1-%d%s: " % (len(KEYS), " [Enter = %s]" % NIVELURI[implicit]["nume"] if implicit else "")
    while True:
        r = input(prompt).strip()
        if not r and implicit:
            return implicit
        if r.isdigit() and 1 <= int(r) <= len(KEYS):
            return KEYS[int(r) - 1]
        if r in NIVELURI:
            return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nivel", choices=KEYS)
    ap.add_argument("--masini", choices=KEYS)
    ap.add_argument("--pietoni", choices=KEYS)
    ap.add_argument("--tramvaie", choices=KEYS)
    ap.add_argument("--scale", type=float, default=1.0)
    ap.add_argument("--fara-satelit", action="store_true")
    ap.add_argument("--start", action="store_true", help="porneste automat simularea")
    ap.add_argument("--consola", action="store_true", help="ruleaza fara interfata grafica (sumo)")
    ap.add_argument("--meniu", action="store_true")
    a = ap.parse_args()
    if not os.path.isfile(NET):
        print("Reteaua nu exista inca. Ruleaza intai construieste.bat (python construieste.py).")
        sys.exit(1)
    if a.meniu or not (a.nivel or a.masini or a.pietoni or a.tramvaie):
        print("=== SIMULARE RONDUL PODU ROS - IASI ===")
        print("1) acelasi nivel pentru toti   2) niveluri diferite pentru masini / pietoni / tramvaie")
        mod = input("Alege 1 sau 2 [Enter = 1]: ").strip()
        if mod == "2":
            a.masini = alege("Nivel trafic MASINI:")
            a.pietoni = alege("Nivel trafic PIETONI:", a.masini)
            a.tramvaie = alege("Nivel trafic TRAMVAIE:", a.masini)
        else:
            a.nivel = alege("Nivel trafic:")
    m = a.masini or a.nivel or "semi_aglomerat"
    p = a.pietoni or a.nivel or m
    t = a.tramvaie or a.nivel or m
    cfg = os.path.join(DIR_SCEN, "personalizat.sumocfg")
    write_sumocfg(cfg, m, p, t, scale=a.scale, satelit=not a.fara_satelit)
    print("\nMasini: %s | Pietoni: %s | Tramvaie: %s | scala %.2f" % (
        NIVELURI[m]["nume"], NIVELURI[p]["nume"], NIVELURI[t]["nume"], a.scale))
    exe = binary("sumo" if a.consola else "sumo-gui")
    cmd = [exe, "-c", cfg]
    if a.start or a.consola:
        cmd.append("--start")
    print(" ".join(cmd))
    subprocess.call(cmd)


if __name__ == "__main__":
    main()

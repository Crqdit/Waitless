# -*- coding: utf-8 -*-
"""
Simulare dupa ORA REALA din Iasi (Europe/Bucharest).

Citeste ora si ziua curenta, alege intensitatea traficului dupa un profil orar tipic
(zi lucratoare / sambata / duminica) si porneste SUMO exact de la ora actuala.
Traficul se schimba automat de la o ora la alta (ex. 16:00 aglomerat -> 17:00 ora de varf).

  python ora_reala.py                    -> de acum, 2 ore, accelerat
  python ora_reala.py --ore 4 --timp-real
  python ora_reala.py --data "2026-10-19 07:30"   (simuleaza o alta zi/ora)
"""
from __future__ import print_function
import os, sys, re, random, argparse, subprocess
from datetime import datetime, timedelta
try:
    from datetime import timezone
except ImportError:
    timezone = None

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from podu_lib import (NIVELURI, NET, DIR_TRAFIC, DIR_SCEN, DIR_RETEA, DIR_GUI, DIR_REZ, binary)
import reguli_circulatie as RC
import verificare_sim as V

# ---------------------------------------------------------------------------
# PROFILE ORARE  (1.00 = ora de varf tipica; le poti ajusta)
# ---------------------------------------------------------------------------
MASINI_REF = NIVELURI["ora_de_varf"]["masini_h"]     # 2900 masini/h la 1.00
PIETONI_REF = NIVELURI["ora_de_varf"]["pietoni_h"]   # 1900 pietoni/h la 1.00

PROFIL_MASINI = {
    "lucratoare": [0.08, 0.05, 0.04, 0.04, 0.06, 0.15, 0.40, 0.85, 1.00, 0.80, 0.65, 0.65,
                   0.70, 0.75, 0.75, 0.80, 0.92, 1.00, 0.95, 0.75, 0.55, 0.40, 0.25, 0.15],
    "sambata":    [0.15, 0.10, 0.07, 0.05, 0.05, 0.08, 0.15, 0.25, 0.38, 0.52, 0.66, 0.76,
                   0.80, 0.76, 0.70, 0.66, 0.66, 0.70, 0.70, 0.62, 0.52, 0.42, 0.32, 0.22],
    "duminica":   [0.15, 0.10, 0.07, 0.05, 0.04, 0.06, 0.10, 0.16, 0.25, 0.38, 0.50, 0.58,
                   0.62, 0.60, 0.56, 0.54, 0.56, 0.60, 0.62, 0.56, 0.46, 0.36, 0.26, 0.18],
}
PROFIL_PIETONI = {
    "lucratoare": [0.03, 0.02, 0.01, 0.01, 0.02, 0.06, 0.25, 0.70, 0.90, 0.70, 0.60, 0.65,
                   0.80, 0.85, 0.80, 0.85, 0.95, 1.00, 0.95, 0.75, 0.50, 0.30, 0.15, 0.06],
    "sambata":    [0.06, 0.04, 0.02, 0.01, 0.01, 0.03, 0.08, 0.20, 0.35, 0.55, 0.75, 0.90,
                   0.95, 0.90, 0.80, 0.75, 0.75, 0.80, 0.80, 0.70, 0.55, 0.40, 0.25, 0.12],
    "duminica":   [0.06, 0.04, 0.02, 0.01, 0.01, 0.02, 0.05, 0.12, 0.25, 0.45, 0.60, 0.70,
                   0.75, 0.70, 0.65, 0.65, 0.70, 0.75, 0.75, 0.65, 0.50, 0.35, 0.20, 0.10],
}
VINERI_SEARA = 1.15     # vineri 16-19 traficul e mai mare -> ambuteiaj

# Tramvaie CTP Iasi (aprox.): interval pe fiecare linie, in secunde; None = nu circula
def interval_tramvai(zi, ora):
    if ora < 5 or ora >= 23:
        return None
    if zi == "lucratoare":
        if 7 <= ora < 9 or 16 <= ora < 19:
            return 360
        if 6 <= ora < 20:
            return 600
        return 900
    if 9 <= ora < 20:
        return 720
    return 1020


def nivel_din_factor(f):
    """transforma intensitatea intr-unul din cele 6 niveluri (pentru comportamentul soferilor)"""
    for lim, lvl in ((0.15, "liber"), (0.35, "relativ_liber"), (0.55, "semi_aglomerat"),
                     (0.82, "aglomerat"), (1.05, "ora_de_varf")):
        if f <= lim:
            return lvl
    return "ambuteiaj"


# ---------------------------------------------------------------------------
# Ora Romaniei (fara pachete externe): EET iarna UTC+2, EEST vara UTC+3
# ---------------------------------------------------------------------------
def ultima_duminica(an, luna):
    d = datetime(an, luna + 1, 1) - timedelta(days=1) if luna < 12 else datetime(an, 12, 31)
    while d.weekday() != 6:
        d -= timedelta(days=1)
    return d


def ora_iasi():
    utc = datetime.now(timezone.utc).replace(tzinfo=None) if timezone else datetime.utcnow()
    start = ultima_duminica(utc.year, 3).replace(hour=1)    # 01:00 UTC
    stop = ultima_duminica(utc.year, 10).replace(hour=1)
    return utc + timedelta(hours=3 if start <= utc < stop else 2)


def tip_zi(d):
    return "duminica" if d.weekday() == 6 else "sambata" if d.weekday() == 5 else "lucratoare"


ZILE = ["luni", "marti", "miercuri", "joi", "vineri", "sambata", "duminica"]


# ---------------------------------------------------------------------------
# Rute valide (deja verificate de SUMO la construire) refolosite ca "rezervor"
# ---------------------------------------------------------------------------
def pool_masini():
    pairs = set()
    for f in sorted(os.listdir(DIR_TRAFIC)):
        if f.startswith("masini_") and f.endswith(".trips.xml"):
            for m in re.finditer(r'<trip [^>]*from="([^"]+)" to="([^"]+)"', open(os.path.join(DIR_TRAFIC, f), encoding="utf-8").read()):
                pairs.add((m.group(1), m.group(2)))
    return sorted(pairs)


def pool_pietoni():
    walks = set()
    for f in sorted(os.listdir(DIR_TRAFIC)):
        if f.startswith("pietoni_") and f.endswith(".trips.xml"):
            for m in re.finditer(r'<person [^>]*>(.*?)</person>', open(os.path.join(DIR_TRAFIC, f), encoding="utf-8").read(), re.S):
                walks.add(" ".join(m.group(1).split()))
    return sorted(walks)


def tram_routes():
    """refoloseste rutele de tramvai (cu statii) generate la construire"""
    txt = open(os.path.join(DIR_TRAFIC, "tramvaie_liber.rou.xml"), encoding="utf-8").read()
    routes = re.findall(r'(<route id="r_tram_\d+".*?</route>)', txt, re.S)
    flows = re.findall(r'<flow id="(tram_[^"]+)" type="tramvai" route="(r_tram_\d+)"[^>]*line="([^"]*)"', txt)
    return routes, flows


def genereaza(t0, ore, seed=1, scara=1.0):
    rnd = random.Random(seed)
    cars, peds = pool_masini(), pool_pietoni()
    if not cars or not peds:
        raise RuntimeError("Nu gasesc traficul generat. Ruleaza intai construieste.bat")
    routes, flows = tram_routes()
    begin = t0.hour * 3600 + t0.minute * 60 + t0.second
    end = begin + int(ore * 3600)
    veh, tram, plan = [], [], []
    # pentru fiecare ora (bucata) din intervalul simulat
    t = begin
    while t < end:
        h_end = min(end, (t // 3600 + 1) * 3600)
        d = t0 + timedelta(seconds=t - begin)
        zi, h = tip_zi(d), d.hour
        fm = PROFIL_MASINI[zi][h] * (VINERI_SEARA if d.weekday() == 4 and 16 <= h < 19 else 1.0)
        fp = PROFIL_PIETONI[zi][h]
        lvl_m, lvl_p = nivel_din_factor(fm), nivel_din_factor(fp)
        # factorii de calibrare (din verificarea automata) -> fara blocaje / coliziuni
        nm = fm * MASINI_REF * V.factor(lvl_m, "masini") * scara
        np_ = fp * PIETONI_REF * V.factor(lvl_p, "pietoni") * scara
        hw = interval_tramvai(zi, h)
        plan.append((d, zi, fm, lvl_m, nm, fp, lvl_p, np_, hw))
        # sosiri aleatoare (proces Poisson)
        nu = RC.URGENTE_H.get(lvl_m, 3)
        for rate, kind, lvl in ((nm, "m", lvl_m), (np_, "p", lvl_p), (nu, "u", lvl_m)):
            if rate <= 0:
                continue
            x = t + rnd.expovariate(rate / 3600.0)
            while x < h_end:
                veh.append((x, kind, lvl))
                x += rnd.expovariate(rate / 3600.0)
        if hw:
            for i, (fid, rid, line) in enumerate(flows):
                off = (i * hw / max(1, len(flows)) + 5) % hw
                x = (t // hw) * hw + off
                if x < t:
                    x += hw
                while x < h_end:
                    tram.append((x, rid, line, hw))
                    x += hw
        t = h_end
    veh.sort()
    tram.sort()
    out = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<!-- trafic dupa ora reala: %s %s, %g ore -->' % (ZILE[t0.weekday()], t0.strftime("%Y-%m-%d %H:%M"), ore),
           '<routes>']
    for r in routes:   # rutele de tramvai cu statiile; durata stationarii se pune pe vehicul
        out.append("    " + re.sub(r'\s*<stop [^>]*/>', "", r))
    stops = {}
    for r in routes:
        rid = re.search(r'id="([^"]+)"', r).group(1)
        stops[rid] = re.findall(r'busStop="([^"]+)"', r)
    items = [(x, "v", k, l) for x, k, l in veh] + [(x, "t", rid, (line, hw)) for x, rid, line, hw in tram]
    items.sort(key=lambda z: z[0])
    nc = npn = nt = nu_id = 0
    for x, typ, a, b in items:
        if typ == "t":
            line, hw = b
            dw = 45 if hw <= 360 else 30 if hw <= 600 else 20
            out.append('    <vehicle id="tram_%s_%d" type="tramvai" route="%s" depart="%.2f" line="%s" departSpeed="max">' % (
                line, nt, a, x, line))
            for s in stops[a]:
                out.append('        <stop busStop="%s" duration="%d"/>' % (s, dw))
            out.append('    </vehicle>')
            nt += 1
        elif a == "u":
            f, to = rnd.choice(cars)
            out.append('    <trip id="urgenta_%d" type="%s" depart="%.2f" from="%s" to="%s" departLane="best" departSpeed="max"/>' % (nu_id, RC.alege_tip(rnd), x, f, to))
            nu_id += 1
        elif a == "m":
            f, to = rnd.choice(cars)
            out.append('    <trip id="masina_%d" type="masina_%s" depart="%.2f" from="%s" to="%s" departLane="best" departSpeed="max"/>' % (nc, b, x, f, to))
            nc += 1
        else:
            out.append('    <person id="pieton_%d" type="pieton_%s" depart="%.2f">%s</person>' % (npn, b, x, rnd.choice(peds)))
            npn += 1
    out += ['</routes>', '']
    with open(os.path.join(DIR_TRAFIC, "ora_reala.rou.xml"), "w", encoding="utf-8") as fo:
        fo.write("\n".join(out))
    return begin, end, plan, (nc, npn, nt)


def tipuri():
    o = ['<?xml version="1.0" encoding="UTF-8"?>', '<additional>']
    for lvl, P in NIVELURI.items():
        o.append('    <vType id="masina_%s" vClass="passenger" %s/>' % (lvl, RC.atribute_masina(P)))
        o.append('    <vType id="pieton_%s" vClass="pedestrian" speedFactor="%s" color="255,40,200" width="0.6" length="0.4"/>' % (lvl, P["ped_speed"]))
    rosu = all(v.get("urgente_trec_pe_rosu", True) for v in V.citeste_calibrare().values()) if V.citeste_calibrare() else True
    o.append(RC.vtypes_urgenta_xml(rosu))
    o += ['</additional>', '']
    with open(os.path.join(DIR_TRAFIC, "tipuri_ora_reala.add.xml"), "w", encoding="utf-8") as f:
        f.write("\n".join(o))


def gui_settings(timp_real):
    src = os.path.join(DIR_GUI, "vizualizare_satelit.settings.xml")
    if not os.path.exists(src):
        src = os.path.join(DIR_GUI, "vizualizare.settings.xml")
    txt = open(src, encoding="utf-8").read()
    # pas de 0.5 s -> 500 ms intarziere = aprox. timp real
    txt = re.sub(r'<delay value="[^"]*"/>', '<delay value="%d"/>' % (480 if timp_real else 40), txt)
    dst = os.path.join(DIR_GUI, "ora_reala.settings.xml")
    with open(dst, "w", encoding="utf-8") as f:
        f.write(txt)
    return dst


def write_cfg(begin, end, gui, verificat=False):
    path = os.path.join(DIR_SCEN, "ora_reala.sumocfg")
    rel = lambda p: os.path.relpath(p, DIR_SCEN).replace("\\", "/")
    add = [os.path.join(DIR_TRAFIC, "tipuri_ora_reala.add.xml"), os.path.join(DIR_TRAFIC, "tipuri_tramvai.add.xml"),
           os.path.join(DIR_RETEA, "statii_tramvai.add.xml"), os.path.join(DIR_RETEA, "treceri_pietoni.add.xml")]
    s = """<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <input>
        <net-file value="%s"/>
        <additional-files value="%s"/>
        <route-files value="%s"/>
    </input>
    <time>
        <begin value="%d"/>
        <end value="%d"/>
        <step-length value="0.5"/>
    </time>
    <processing>
        <ignore-route-errors value="true"/>
        <time-to-teleport value="%d"/>
        <pedestrian.model value="striping"/>
        <collision.action value="warn"/>
        <collision.check-junctions value="true"/>
    </processing>
    <routing>
        <device.rerouting.probability value="0.3"/>
        <device.rerouting.period value="120"/>
    </routing>
    <output>
        <summary-output value="%s"/>
    </output>
    <report>
        <no-step-log value="true"/>
        <human-readable-time value="true"/>
        <duration-log.statistics value="true"/>
    </report>
    <gui_only>
        <gui-settings-file value="%s"/>
    </gui_only>
</configuration>
""" % (rel(NET), ",".join(rel(a) for a in add if os.path.exists(a)), rel(os.path.join(DIR_TRAFIC, "ora_reala.rou.xml")),
       begin, end + 600, -1 if verificat else 900, rel(os.path.join(DIR_REZ, "sumar_ora_reala.xml")), rel(gui))
    with open(path, "w", encoding="utf-8") as f:
        f.write(s)
    return path


def genereaza_verificat(t0, ore, verifica=True, log=print, incercari=5):
    """genereaza traficul de la ora t0 si il verifica in SUMO (fara GUI); daca apar teleportari,
    coliziuni sau pietoni blocati, reduce putin traficul si reincearca"""
    scara = 1.0
    for i in range(1, incercari + 1):
        begin, end, plan, cnt = genereaza(t0, ore, scara=scara)
        if not verifica:
            return begin, end, False, plan, cnt
        cfg = write_cfg(begin, end, gui_settings(False), verificat=False)
        r = V.ruleaza_test(cfg, "ora_reala")
        log("  verificare ora reala (%d): teleportari %s, coliziuni %s, pietoni blocati %s%s" % (
            i, r["teleport"], r["coliziuni"], r["blocati"], "  OK" if r["ok"] else ""))
        if r["ok"]:
            return begin, end, True, plan, cnt
        if r.get("eroare") or r.get("cod") not in (0, None):
            log("  eroare la verificare - vezi rezultate/_test_ora_reala.log")
            return begin, end, False, plan, cnt
        scara *= 0.85
    return begin, end, False, plan, cnt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ore", type=float, default=None, help="cate ore sa simuleze (implicit 2)")
    ap.add_argument("--timp-real", action="store_true", help="simularea merge in ritmul ceasului real")
    ap.add_argument("--data", help='alta data/ora, ex. "2026-10-19 07:30" (implicit: acum, ora Iasi)')
    ap.add_argument("--nu-porni", action="store_true", help="doar genereaza fisierele")
    ap.add_argument("--meniu", action="store_true")
    ap.add_argument("--fara-verificare", action="store_true", help="nu verifica simularea inainte")
    a = ap.parse_args()
    if not os.path.isfile(NET):
        print("Reteaua nu exista. Ruleaza intai construieste.bat"); sys.exit(1)
    t0 = datetime.strptime(a.data, "%Y-%m-%d %H:%M") if a.data else ora_iasi()
    if a.meniu:
        print("=== SIMULARE DUPA ORA REALA - PODU ROS, IASI ===")
        print("Acum in Iasi: %s, %s" % (ZILE[t0.weekday()], t0.strftime("%d.%m.%Y %H:%M")))
        r = input("Cate ore sa simulez? [Enter = 2]: ").strip()
        a.ore = float(r.replace(",", ".")) if r else 2
        r = input("1) accelerat   2) in timp real (1 secunda = 1 secunda)  [Enter = 1]: ").strip()
        a.timp_real = (r == "2")
    ore = a.ore or 2
    tipuri()
    print("Verific simularea in SUMO (fara teleportari si coliziuni) ...")
    begin, end, ok, plan, (nc, npn, nt) = genereaza_verificat(t0, ore, verifica=not a.fara_verificare)
    gui = gui_settings(a.timp_real)
    cfg = write_cfg(begin, end, gui, verificat=ok)
    print("Verificare: %s" % ("OK - fara teleportari si coliziuni" if ok else "nereusita, teleportarea ramane ca plasa de siguranta"))
    print("\nStart: %s, %s  (%s)" % (ZILE[t0.weekday()], t0.strftime("%d.%m.%Y %H:%M"), "timp real" if a.timp_real else "accelerat"))
    print("%-7s %-11s %-22s %-22s %s" % ("Ora", "Zi", "Masini", "Pietoni", "Tramvai/linie"))
    for d, zi, fm, lm, nm, fp, lp, np_, hw in plan:
        print("%-7s %-11s %4d/h %-15s %4d/h %-15s %s" % (d.strftime("%H:%M"), zi, nm, NIVELURI[lm]["nume"], np_,
                                                     NIVELURI[lp]["nume"], "la %d min" % (hw // 60) if hw else "nu circula"))
    print("Total: %d masini, %d pietoni, %d tramvaie  ->  %s" % (nc, npn, nt, cfg))
    if not a.nu_porni:
        subprocess.call([binary("sumo-gui"), "-c", cfg])


if __name__ == "__main__":
    main()

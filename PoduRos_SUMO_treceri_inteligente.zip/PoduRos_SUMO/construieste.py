# -*- coding: utf-8 -*-
"""
Construieste tot proiectul SUMO pentru rondul Podu Ros (Iasi) din map.osm:
  1. reteaua (drumuri + trotuare + treceri de pietoni + linii de tramvai separate)
  2. imaginea satelit de fundal (geo-referentiata, aliniata cu reteaua)
  3. evidentierea trecerilor de pietoni
  4. statiile si liniile de tramvai (1, 7, 9, 13) din relatiile OSM
  5. trafic masini / pietoni / tramvaie pentru 6 niveluri
  6. cate un .sumocfg pentru fiecare nivel

Utilizare:  python construieste.py [--fara-satelit] [--google-key CHEIE] [--zoom 19]
"""
from __future__ import print_function
import os, sys, math, random, subprocess, argparse, time, shutil
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from podu_lib import *  # noqa
import reguli_circulatie as RC

LOG = []


def log(msg):
    print(msg)
    LOG.append(msg)


def run(cmd, logfile=None):
    log("  > " + " ".join('"%s"' % c if " " in c else c for c in cmd))
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    out = p.stdout.decode("utf-8", "replace")
    if logfile:
        with open(logfile, "a", encoding="utf-8") as f:
            f.write("\n\n### " + " ".join(cmd) + "\n" + out)
    return p.returncode, out


def mkdirs():
    for d in (DIR_RETEA, DIR_TRAFIC, DIR_SCEN, DIR_GUI, DIR_SAT, DIR_REZ):
        if not os.path.isdir(d):
            os.makedirs(d)


# ---------------------------------------------------------------------------
# 1. RETEA
# ---------------------------------------------------------------------------
def build_net():
    log("\n[1/7] Generez reteaua cu netconvert ...")
    nc = binary("netconvert")
    home = sumo_home()
    tm = os.path.join(home, "data", "typemap") if home else ""
    types = [os.path.join(tm, f) for f in ("osmNetconvert.typ.xml", "osmNetconvertUrbanDe.typ.xml",
                                           "osmNetconvertPedestrians.typ.xml")]
    types = [t for t in types if os.path.isfile(t)]
    extra_typ = os.path.join(DIR_RETEA, "tipuri_drumuri.typ.xml")
    with open(extra_typ, "w", encoding="utf-8") as f:
        # strazile de serviciu / acces devin circulabile -> nu raman strazi "moarte"
        f.write('<types>\n'
                '    <type id="highway.service" priority="2" numLanes="1" speed="8.33" '
                'allow="passenger taxi delivery bicycle pedestrian emergency" oneway="0" sidewalkWidth="1.5"/>\n'
                '    <type id="highway.living_street" priority="2" numLanes="1" speed="5.56" '
                'allow="passenger taxi delivery bicycle pedestrian emergency" oneway="0"/>\n'
                '    <type id="highway.unclassified" priority="4" numLanes="1" speed="13.89" '
                'disallow="tram rail_urban rail rail_electric rail_fast ship cable_car subway aircraft" oneway="0" sidewalkWidth="2"/>\n'
                '</types>\n')
    if types:
        types.append(extra_typ)
    base = [nc, "--osm-files", OSM, "-o", NET, "--proj.utm", "true"]
    if types:
        base += ["--type-files", ",".join(types)]
    # doar zona din map.osm (<bounds>), cu o margine mica pentru capetele trecerilor
    mla, mlo, Mla, Mlo = osm_bounds()
    pad = 0.0003
    base += ["--keep-edges.in-geo-boundary", "%.7f,%.7f,%.7f,%.7f" % (mlo - pad, mla - pad, Mlo + pad, Mla + pad)]
    real = os.path.join(ROOT, "treceri_pietoni_reale.con.xml")
    cfg = os.path.join(ROOT, "treceri_pietoni.json")
    if os.path.isfile(cfg):
        # trecerile reale sunt descrise prin pozitie (lat/lon) -> se potrivesc pe orice map.osm
        cross = ["--crossings.guess", "false", "--osm.crossings", "false"]
        log("  Treceri de pietoni: doar cele din treceri_pietoni.json")
    elif os.path.isfile(real):
        # DOAR trecerile de pietoni reale (lista din fisier), nu cele ghicite din OpenStreetMap
        cross = ["--crossings.guess", "false", "--osm.crossings", "false", "-x", real]
        log("  Treceri de pietoni: doar cele din treceri_pietoni_reale.con.xml")
    else:
        cross = ["--crossings.guess", "true", "--osm.crossings", "true"]
    full = cross + ["--sidewalks.guess", "true", "--walkingareas", "true",
            "--osm.sidewalks", "true",
            "--geometry.remove", "true", "--roundabouts.guess", "true", "--ramps.guess", "true",
            "--junctions.join", "true", "--tls.guess-signals", "true", "--tls.discard-simple", "true",
            "--tls.join", "true", "--tls.default-type", "actuated",
            "--no-turnarounds.tls", "true", "--remove-edges.isolated", "true",
            "--output.street-names", "true", "--output.original-names", "true", "--ignore-errors", "true"] + RC.NETCONVERT_OPTS
    medium = cross + ["--sidewalks.guess", "true", "--walkingareas", "true",
              "--geometry.remove", "true", "--roundabouts.guess", "true", "--tls.guess-signals", "true",
              "--remove-edges.isolated", "true", "--output.street-names", "true", "--ignore-errors", "true"]
    minimal = cross + ["--sidewalks.guess", "true", "--walkingareas", "true"]
    lf = os.path.join(DIR_RETEA, "netconvert.log")
    if os.path.exists(lf):
        os.remove(lf)
    for name, opts in (("complet", full), ("mediu", medium), ("minimal", minimal)):
        code, out = run(base + opts, lf)
        if code == 0 and os.path.isfile(NET):
            log("  Retea generata (set optiuni: %s)" % name)
            if os.path.isfile(cfg):
                con = resolve_crossings(cfg)
                if con:
                    # trecerile se adauga pe reteaua deja generata (aceleasi id-uri de noduri si strazi)
                    tmp = NET + ".treceri.xml"
                    code2, _ = run([nc, "-s", NET, "-x", con, "-o", tmp, "--crossings.guess", "false",
                                    "--walkingareas", "true", "--ignore-errors", "true"], lf)
                    if code2 == 0 and os.path.isfile(tmp):
                        os.replace(tmp, NET)
                        n2 = Net(NET)
                        log("  Treceri de pietoni adaugate in retea: %d" % len(n2.crossings))
                    else:
                        log("  ATENTIE: nu am putut adauga trecerile (vezi retea/netconvert.log)")
            return
        log("  netconvert a esuat cu setul '%s', incerc mai simplu ... (vezi retea/netconvert.log)" % name)
    raise RuntimeError("netconvert nu a reusit sa genereze reteaua - vezi retea/netconvert.log")


def _heading_at(net, eid, node):
    d = net.edges[eid]
    sh = d["lanes"][0]["shape"]
    if d["to"] == node:
        sh, sens = sh[::-1], "in"
    elif d["frm"] == node:
        sens = "out"
    else:
        return None, None
    x0, y0 = sh[0]
    x1, y1 = sh[-1]
    acc = 0.0
    for (a, b), (c, e) in zip(sh[:-1], sh[1:]):
        acc += math.hypot(c - a, e - b)
        x1, y1 = c, e
        if acc >= 8:
            break
    return sens, math.degrees(math.atan2(y1 - y0, x1 - x0))


def _angle_diff(a, b):
    return abs((a - b + 180.0) % 360.0 - 180.0)


def resolve_crossings(cfg):
    """Gaseste nodurile/muchiile din reteaua noua pentru trecerile din treceri_pietoni.json."""
    import json
    net = Net(NET)
    data = json.load(open(cfg, encoding="utf-8"))
    inc = {}
    for eid, d in net.edges.items():
        if d["function"]:
            continue
        for node in (d["frm"], d["to"]):
            sens, h = _heading_at(net, eid, node)
            if sens:
                inc.setdefault(node, []).append((eid, sens, h))
    lines, ok, lipsa = [], 0, []
    seen = set()
    for t in data["treceri"]:
        x, y = net.xy(t["lat"], t["lon"])
        if t["nod"] in net.jxy and math.hypot(net.jxy[t["nod"]][0] - x, net.jxy[t["nod"]][1] - y) < 20:
            cands = [t["nod"]]
        else:
            cands = sorted((math.hypot(jx - x, jy - y), j) for j, (jx, jy) in net.jxy.items() if j in inc)
            cands = [j for dd, j in cands if dd < 30][:6]
        found = None
        for node in cands:
            edges = []
            for m in t["muchii"]:
                best = None
                for eid, sens, h in inc.get(node, ()):
                    if sens != m["sens"]:
                        continue
                    same = eid.lstrip("-").split("#")[0] == m["baza"] and eid.startswith("-") == m["invers"]
                    diff = _angle_diff(h, m["directie"])
                    if (same and diff < 45) or diff < 20:
                        score = diff - (100 if same else 0)
                        if best is None or score < best[0]:
                            best = (score, eid)
                if best is None:
                    break
                edges.append(best[1])
            if len(edges) == len(t["muchii"]):
                found = (node, edges)
                break
        if not found:
            lipsa.append("%s (%s)" % (t["zona"], t["nod"]))
            continue
        key = (found[0], tuple(sorted(found[1])))
        if key in seen:
            continue
        seen.add(key)
        ok += 1
        lines.append('    <crossing node="%s" edges="%s" priority="true" width="%.2f"/> <!-- %s -->'
                     % (found[0], " ".join(found[1]), t["latime"], t["zona"]))
    log("  Treceri de pietoni potrivite pe retea: %d din %d" % (ok, len(data["treceri"])))
    if lipsa:
        log("  ATENTIE: nu am gasit in retea trecerile: " + ", ".join(lipsa))
    if not lines:
        return None
    path = os.path.join(DIR_RETEA, "treceri_pietoni.con.xml")
    with open(path, "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<connections>\n' + "\n".join(lines) + "\n</connections>\n")
    return path


# ---------------------------------------------------------------------------
# 2. SATELIT
# ---------------------------------------------------------------------------
def lonlat_to_px(lat, lon, z):
    s = math.sin(math.radians(lat))
    n = 256.0 * 2 ** z
    return (lon + 180.0) / 360.0 * n, (0.5 - math.log((1 + s) / (1 - s)) / (4 * math.pi)) * n


def px_to_lonlat(px, py, z):
    n = 256.0 * 2 ** z
    lon = px / n * 360.0 - 180.0
    lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * py / n))))
    return lat, lon


def download(url, path):
    try:
        from urllib.request import Request, urlopen
    except ImportError:
        from urllib2 import Request, urlopen
    if os.path.isfile(path) and os.path.getsize(path) > 1500:
        return True
    err = "raspuns gol"
    for attempt in range(3):
        try:
            req = Request(url, headers={"User-Agent": "SUMO-PoduRos/1.0 (traffic simulation)"})
            data = urlopen(req, timeout=30).read()
            if len(data) > 1000:
                with open(path, "wb") as f:
                    f.write(data)
                return True
        except Exception as ex:
            err = str(ex)
        time.sleep(1 + attempt)
    log("    nu am putut descarca %s (%s)" % (url.split("key=")[0], err))
    return False


def decal_xml(net, path, px0, py0, px1, py1, z):
    """decal pentru o imagine care acopera [px0,px1]x[py0,py1] (pixeli Web-Mercator la zoom z)"""
    corners = [net.xy(*px_to_lonlat(px, py, z)) for px, py in ((px0, py0), (px1, py0), (px1, py1), (px0, py1))]
    cx = sum(c[0] for c in corners) / 4; cy = sum(c[1] for c in corners) / 4
    w = (math.hypot(corners[1][0] - corners[0][0], corners[1][1] - corners[0][1]) +
         math.hypot(corners[2][0] - corners[3][0], corners[2][1] - corners[3][1])) / 2
    h = (math.hypot(corners[3][0] - corners[0][0], corners[3][1] - corners[0][1]) +
         math.hypot(corners[2][0] - corners[1][0], corners[2][1] - corners[1][1])) / 2
    return ('        <decal file="%s" centerX="%.2f" centerY="%.2f" width="%.2f" height="%.2f" '
            'rotation="0.00" layer="-1.00" screenRelative="0"/>' % (os.path.abspath(path), cx, cy, w * 1.004, h * 1.004))


def build_satellite(net, zoom, google_key, margin_m=150):
    log("\n[2/7] Descarc imaginea satelit (zoom %d, sursa: %s) ..." % (zoom, "Google Static Maps" if google_key else "Esri World Imagery"))
    minlat, minlon, maxlat, maxlon = osm_bounds()
    dlat = margin_m / 111320.0; dlon = margin_m / (111320.0 * math.cos(math.radians((minlat + maxlat) / 2)))
    minlat -= dlat; maxlat += dlat; minlon -= dlon; maxlon += dlon
    X0, Y0 = lonlat_to_px(maxlat, minlon, zoom)   # NV
    X1, Y1 = lonlat_to_px(minlat, maxlon, zoom)   # SE
    jobs = []   # (url, path, px0, py0, px1, py1)
    if google_key:
        size, logo = 640, 60   # imaginile se suprapun 60px ca sa ascunda sigla de jos
        step_y = size - logo
        cy = Y0 + size / 2.0
        r = 0
        while cy - size / 2.0 < Y1:
            cx = X0 + size / 2.0; c = 0
            while cx - size / 2.0 < X1:
                lat, lon = px_to_lonlat(cx, cy, zoom)
                url = ("https://maps.googleapis.com/maps/api/staticmap?center=%.7f,%.7f&zoom=%d&size=640x640"
                       "&scale=2&maptype=satellite&format=jpg&key=%s" % (lat, lon, zoom, google_key))
                jobs.append((url, os.path.join(DIR_SAT, "g_%d_%02d_%02d.jpg" % (zoom, r, c)),
                             cx - size / 2.0, cy - size / 2.0, cx + size / 2.0, cy + size / 2.0))
                cx += size; c += 1
            cy += step_y; r += 1
    else:
        for ty in range(int(Y0 // 256), int(Y1 // 256) + 1):
            for tx in range(int(X0 // 256), int(X1 // 256) + 1):
                url = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/%d/%d/%d" % (zoom, ty, tx)
                jobs.append((url, os.path.join(DIR_SAT, "e_%d_%d_%d.jpg" % (zoom, tx, ty)),
                             tx * 256, ty * 256, (tx + 1) * 256, (ty + 1) * 256))
    log("  %d imagini de descarcat ..." % len(jobs))
    with ThreadPoolExecutor(max_workers=6) as ex:
        ok = list(ex.map(lambda j: download(j[0], j[1]), jobs))
    good = [j for j, o in zip(jobs, ok) if o]
    log("  %d/%d imagini descarcate" % (len(good), len(jobs)))
    if not good:
        log("  ATENTIE: nu s-a descarcat nicio imagine (fara internet?). Simularea merge si fara satelit.")
        return []
    inner = (minlat + dlat * 0.3, minlon + dlon * 0.3, maxlat - dlat * 0.3, maxlon - dlon * 0.3)
    try:
        return [mosaic(net, good, zoom, inner, 2 if google_key else 1)]
    except Exception as ex:
        log("  Nu am putut lipi imaginile intr-una singura (%s) - folosesc imaginile separat." % ex)
        return [decal_xml(net, j[1], j[2], j[3], j[4], j[5], zoom) for j in good]


def get_pil():
    try:
        from PIL import Image
        return Image
    except ImportError:
        log("  Instalez Pillow (pentru lipirea imaginilor satelit) ...")
        subprocess.call([sys.executable, "-m", "pip", "install", "--user", "pillow"])
        import site, importlib
        try:
            site.addsitedir(site.getusersitepackages())
        except Exception:
            pass
        importlib.invalidate_caches()
        from PIL import Image
        return Image


def mosaic(net, jobs, zoom, inner, s):
    """Lipeste imaginile intr-un mozaic si il reproiecteaza exact pe coordonatele retelei (UTM),
    astfel incat poza sa se suprapuna perfect peste drumuri."""
    Image = get_pil()
    mx0 = min(j[2] for j in jobs); my0 = min(j[3] for j in jobs)
    mx1 = max(j[4] for j in jobs); my1 = max(j[5] for j in jobs)
    W, H = int(round((mx1 - mx0) * s)), int(round((my1 - my0) * s))
    canvas = Image.new("RGB", (W, H), (40, 40, 40))
    for url, path, px0, py0, px1, py1 in jobs:   # ordinea conteaza (Google: randul urmator acopera sigla)
        im = Image.open(path).convert("RGB")
        w, h = int(round((px1 - px0) * s)), int(round((py1 - py0) * s))
        if im.size != (w, h):
            im = im.resize((w, h), Image.LANCZOS)
        canvas.paste(im, (int(round((px0 - mx0) * s)), int(round((py0 - my0) * s))))
    # dreptunghi in coordonate retea, complet acoperit de imagini
    minlat, minlon, maxlat, maxlon = inner
    sw, se, ne, nw = (net.xy(minlat, minlon), net.xy(minlat, maxlon), net.xy(maxlat, maxlon), net.xy(maxlat, minlon))
    x0, x1 = max(sw[0], nw[0]), min(se[0], ne[0])
    y0, y1 = max(sw[1], se[1]), min(nw[1], ne[1])
    lat, lon = net.lonlat((x0 + x1) / 2, (y0 + y1) / 2)
    res = 156543.03392 * math.cos(math.radians(lat)) / (2 ** zoom) / s   # metri / pixel
    res = max(res, max(x1 - x0, y1 - y0) / 8000.0)
    OW, OH = int((x1 - x0) / res), int((y1 - y0) / res)

    def src(i, j):   # pixel iesire -> pixel mozaic
        la, lo = net.lonlat(x0 + i * res, y1 - j * res)
        px, py = lonlat_to_px(la, lo, zoom)
        return (px - mx0) * s, (py - my0) * s
    c = src(0, 0); a = src(OW, 0); b = src(0, OH)
    coef = ((a[0] - c[0]) / OW, (b[0] - c[0]) / OH, c[0], (a[1] - c[1]) / OW, (b[1] - c[1]) / OH, c[1])
    out = canvas.transform((OW, OH), Image.AFFINE, coef, resample=Image.BICUBIC)
    path = os.path.join(DIR_SAT, "podu_ros_satelit.jpg")
    out.save(path, quality=90)
    log("  Imagine satelit: %s (%dx%d px, %.2f m/px)" % (os.path.basename(path), OW, OH, res))
    return ('        <decal file="%s" centerX="%.2f" centerY="%.2f" width="%.2f" height="%.2f" '
            'rotation="0.00" layer="-1.00" screenRelative="0"/>'
            % (os.path.abspath(path), (x0 + x1) / 2, (y0 + y1) / 2, OW * res, OH * res))


def write_gui_settings(net, decals):
    minlat, minlon, maxlat, maxlon = osm_bounds()
    cx, cy = net.xy((minlat + maxlat) / 2, (minlon + maxlon) / 2)

    def settings(dec, scheme):
        s = ['<viewsettings>',
             '    <scheme name="podu_ros">',
             '        <vehicles vehicleMode="0" vehicleQuality="2" vehicle_minSize="1.00" vehicle_exaggeration="1.00" vehicle_constantSize="0"/>',
             '        <persons personMode="0" personQuality="2" person_minSize="3.00" person_exaggeration="3.00" person_constantSize="0"/>',
             '    </scheme>',
             '    <viewport zoom="350" x="%.2f" y="%.2f" angle="0.00"/>' % (cx, cy),
             '    <delay value="40"/>']
        if dec:
            s += ['    <decals>'] + dec + ['    </decals>']
        s += ['</viewsettings>', '']
        return "\n".join(s)
    with open(os.path.join(DIR_GUI, "vizualizare.settings.xml"), "w", encoding="utf-8") as f:
        f.write(settings([], "real world"))
    if decals:
        with open(os.path.join(DIR_GUI, "vizualizare_satelit.settings.xml"), "w", encoding="utf-8") as f:
            f.write(settings(decals, "real world"))


# ---------------------------------------------------------------------------
# 3. TRECERI DE PIETONI EVIDENTIATE
# ---------------------------------------------------------------------------
def build_crossings(net):
    log("\n[3/7] Evidentiez trecerile de pietoni ...")
    out = ['<?xml version="1.0" encoding="UTF-8"?>', '<additional>',
           '    <!-- galben = trecere de pietoni nesemaforizata (pietonul are prioritate)',
           '         verde  = trecere de pietoni semaforizata -->']
    n = 0
    for c in net.crossings:
        lane = c["lanes"][0]
        if len(lane["shape"]) < 2:
            continue
        tl = net.junctions.get(c["junction"]) in ("traffic_light", "traffic_light_unregulated", "traffic_light_right_on_red")
        col = "0,230,90" if tl else "255,215,0"
        tip = "trecere_semaforizata" if tl else "trecere_pietoni"
        shp = buffer_polyline(lane["shape"], lane["width"] + 1.2)
        out.append('    <poly id="tpc_%s" type="%s" color="%s,255" fill="0" lineWidth="0.5" layer="0.5" shape="%s"/>' % (c["id"].lstrip(":"), tip, col, shp))
        n += 1
    # trecerile marite (C1 capatul podului, C5 bulevardul spre est): banda continua peste toate segmentele
    benzi = []
    cfg = os.path.join(ROOT, "treceri_pietoni.json")
    if os.path.isfile(cfg):
        import json
        for b in json.load(open(cfg, encoding="utf-8")).get("benzi_marite", []):
            benzi.append((b["id"], [net.xy(la, lo) for la, lo in b["puncte_latlon"]], b["latime"]))
    for bid, pts, lat in benzi:
        shp = buffer_polyline(pts, lat)
        out.append('    <poly id="banda_%s" type="trecere_marita" color="0,230,90,90" fill="1" layer="0.4" shape="%s"/>' % (bid, shp))
        out.append('    <poly id="banda_%s_contur" type="trecere_marita" color="0,230,90,255" fill="0" lineWidth="0.6" layer="0.5" shape="%s"/>' % (bid, shp))
    out += ['</additional>', '']
    with open(os.path.join(DIR_RETEA, "treceri_pietoni.add.xml"), "w", encoding="utf-8") as f:
        f.write("\n".join(out))
    log("  %d treceri de pietoni evidentiate" % n)
    return n


# ---------------------------------------------------------------------------
# 4. TRAMVAIE
# ---------------------------------------------------------------------------
def tram_analysis(net, osm_root):
    tram = set(e for e in net.normal_edges("tram"))
    succ = {e: set(t for t in net.succ.get(e, ()) if t in tram) for e in tram}
    pred = {e: set() for e in tram}
    for e, ss in succ.items():
        for t in ss:
            pred[t].add(e)
    sources = sorted(e for e in tram if not pred[e])
    paths = []

    def dfs(e, p):
        p = p + [e]
        if len(paths) > 200:
            return
        nxt = [n for n in succ[e] if n not in p]
        if not nxt:
            if len(p) > 1 or not succ[e]:
                paths.append(p)
            return
        for n in sorted(nxt):
            dfs(n, p)
    for s in sources:
        dfs(s, [])
    # linii din relatiile OSM
    lines = []
    for rel in osm_root.findall("relation"):
        t = {x.get("k"): x.get("v") for x in rel.findall("tag")}
        if t.get("route") != "tram" or t.get("type") not in (None, "route"):
            continue
        ways = set(m.get("ref") for m in rel.findall("member") if m.get("type") == "way")
        best, bscore = None, 0.0
        for i, p in enumerate(paths):
            ids = [e.lstrip("-").split("#")[0] for e in p]
            sc = sum(1 for x in ids if x in ways) / float(len(ids))
            if sc > bscore + 1e-9 or (abs(sc - bscore) < 1e-9 and best is not None and len(p) > len(paths[best])):
                best, bscore = i, sc
        ref = t.get("ref")
        if not ref:
            nm = t.get("name", "")
            ref = "".join(ch for ch in nm.split(":")[0] if ch.isdigit()) or "?"
        if best is not None and bscore >= 0.5:
            lines.append(dict(ref=ref, name=t.get("name", "Tramvai " + ref), path=best))
    if not lines:   # nu am recunoscut liniile -> cate o linie generica pe fiecare traseu
        lines = [dict(ref="T%d" % (i + 1), name="Tramvai traseu %d" % (i + 1), path=i) for i in range(len(paths))]
    return tram, paths, lines


def tram_stops(net, osm_root, tram):
    stops = []
    for n in osm_root.findall("node"):
        t = {x.get("k"): x.get("v") for x in n.findall("tag")}
        if not (t.get("railway") == "tram_stop" or (t.get("public_transport") == "stop_position" and t.get("tram") == "yes")):
            continue
        p = net.xy(float(n.get("lat")), float(n.get("lon")))
        best = None
        for e in tram:
            for l in net.edges[e]["lanes"]:
                if not net.lane_allows(l, "tram"):
                    continue
                d, pos = dist_point_polyline(p, l["shape"])
                if best is None or d < best[0]:
                    best = (d, l, pos, e)
        if best and best[0] < 15:
            d, l, pos, e = best
            end = min(l["length"], max(pos + 5, min(30.0, l["length"])))
            start = max(0.0, end - 30.0)
            sid = "statie_%s" % n.get("id")
            if any(s["lane"] == l["id"] and abs(s["end"] - end) < 20 for s in stops):
                continue
            stops.append(dict(id=sid, name=t.get("name", "Statie"), lane=l["id"], edge=e, start=start, end=end))
    return stops


def build_trams(net, osm_root):
    log("\n[4/7] Statii si linii de tramvai ...")
    tram, paths, lines = tram_analysis(net, osm_root)
    stops = tram_stops(net, osm_root, tram)
    log("  %d segmente de cale de rulare, %d trasee, %d linii, %d statii" % (len(tram), len(paths), len(lines), len(stops)))
    for ln in lines:
        log("    linia %s: %s" % (ln["ref"], ln["name"]))
    out = ['<?xml version="1.0" encoding="UTF-8"?>', '<additional>']
    for s in stops:
        lns = " ".join(sorted(set(l["ref"] for l in lines if s["edge"] in paths[l["path"]])))
        out.append('    <busStop id="%s" name="%s" lane="%s" startPos="%.2f" endPos="%.2f" lines="%s" friendlyPos="true"/>'
                   % (s["id"], s["name"], s["lane"], s["start"], s["end"], lns))
    out += ['</additional>', '']
    with open(os.path.join(DIR_RETEA, "statii_tramvai.add.xml"), "w", encoding="utf-8") as f:
        f.write("\n".join(out))
    with open(os.path.join(DIR_TRAFIC, "tipuri_tramvai.add.xml"), "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<additional>\n'
                '    <vType id="tramvai" vClass="tram" length="27.0" minGap="3.0" maxSpeed="13.89" accel="1.0" '
                'decel="1.3" emergencyDecel="2.5" sigma="0.1" color="230,30,30" guiShape="rail/railcar"/>\n'
                '</additional>\n')
    for lvl, P in NIVELURI.items():
        hw, dw = P["tram_interval"], P["tram_stationare"]
        o = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<!-- tramvaie - nivel %s: un tramvai la %d s pe fiecare linie, stationare %d s -->' % (P["nume"], hw, dw),
             '<routes>']
        for i, ln in enumerate(lines):
            p = paths[ln["path"]]
            rid = "r_tram_%d" % i
            o.append('    <route id="%s" edges="%s">' % (rid, " ".join(p)))
            sts = [s for s in stops if s["edge"] in p]
            sts.sort(key=lambda s: (p.index(s["edge"]), s["end"]))
            for s in sts:
                o.append('        <stop busStop="%s" duration="%d"/>' % (s["id"], dw))
            o.append('    </route>')
        for i, ln in enumerate(lines):
            begin = int((i * hw / max(1, len(lines))) % hw) + 5
            safe = "".join(ch if ch.isalnum() else "_" for ch in ln["ref"])
            o.append('    <flow id="tram_%s_%d" type="tramvai" route="r_tram_%d" begin="%d" end="%d" period="%d" line="%s" departSpeed="max"/>'
                     % (safe, i, i, begin, DURATA, hw, ln["ref"]))
        o += ['</routes>', '']
        with open(os.path.join(DIR_TRAFIC, "tramvaie_%s.rou.xml" % lvl), "w", encoding="utf-8") as f:
            f.write("\n".join(o))
    return lines, stops


# ---------------------------------------------------------------------------
# 5. MASINI + PIETONI
# ---------------------------------------------------------------------------
def write_vtypes():
    for lvl, P in NIVELURI.items():
        with open(os.path.join(DIR_TRAFIC, "tipuri_masini_%s.add.xml" % lvl), "w", encoding="utf-8") as f:
            f.write('<?xml version="1.0" encoding="UTF-8"?>\n<additional>\n'
                    '    <!-- soferi - nivel %s (regulile de circulatie: vezi reguli_circulatie.py) -->\n'
                    '    <vType id="masina" vClass="passenger" %s/>\n</additional>\n'
                    % (P["nume"], RC.atribute_masina(P)))
        with open(os.path.join(DIR_TRAFIC, "tipuri_pietoni_%s.add.xml" % lvl), "w", encoding="utf-8") as f:
            f.write('<?xml version="1.0" encoding="UTF-8"?>\n<additional>\n'
                    '    <!-- pietoni - nivel %s -->\n'
                    '    <vType id="pieton" vClass="pedestrian" speedFactor="%s" color="255,40,200" width="0.6" length="0.4"/>\n</additional>\n'
                    % (P["nume"], P["ped_speed"]))


def random_trips(lvl, kind, period, seed):
    rt = tool("randomTrips.py")
    if kind == "masini":
        out = os.path.join(DIR_TRAFIC, "masini_%s.trips.xml" % lvl)
        add = os.path.join(DIR_TRAFIC, "tipuri_masini_%s.add.xml" % lvl)
        extra = ["--vclass", "passenger", "--fringe-factor", "20", "--min-distance", "250",
                 "--trip-attributes", 'type="masina" departLane="best" departSpeed="max"', "--prefix", "masina_"]
    else:
        out = os.path.join(DIR_TRAFIC, "pietoni_%s.trips.xml" % lvl)
        add = os.path.join(DIR_TRAFIC, "tipuri_pietoni_%s.add.xml" % lvl)
        extra = ["--pedestrians", "--vclass", "pedestrian", "--min-distance", "80", "--max-distance", "900",
                 "--fringe-factor", "3", "--trip-attributes", 'type="pieton"', "--prefix", "pieton_"]
    if rt is None:
        return None
    cmd = [sys.executable, rt, "-n", NET, "-o", out, "-b", "0", "-e", str(DURATA), "-p", "%.4f" % period,
           "--seed", str(seed), "--validate", "-a", add,
           "-r", os.path.join(DIR_TRAFIC, "_rute_temp.rou.xml")] + extra
    code, txt = run(cmd, os.path.join(DIR_TRAFIC, "randomTrips.log"))
    if code == 0 and os.path.isfile(out):
        return out
    log("    randomTrips a esuat pentru %s/%s, folosesc generatorul intern" % (kind, lvl))
    return None


def reachable(net, src, vclass):
    seen = {src}; st = [src]
    while st:
        e = st.pop()
        for n in net.succ.get(e, ()):
            if n not in seen and (n.startswith(":") or net.edge_allows(n, vclass)):
                seen.add(n); st.append(n)
    return seen


def fallback_trips(net, lvl, kind, period, seed):
    rnd = random.Random(seed)
    if kind == "masini":
        edges = net.normal_edges("passenger")
        src = [e for e in edges if net.junctions.get(net.edges[e]["frm"]) == "dead_end"] or edges
        dst = [e for e in edges if net.junctions.get(net.edges[e]["to"]) == "dead_end"] or edges
        reach = {s: reachable(net, s, "passenger") for s in src}
        pairs = [(s, d) for s in src for d in dst if d in reach[s] and d != s]
        if not pairs:
            pairs = [(s, d) for s in src for d in dst if s != d]
    else:
        edges = net.normal_edges("pedestrian")
        pairs = None
    out = os.path.join(DIR_TRAFIC, "%s_%s.trips.xml" % (kind, lvl))
    o = ['<?xml version="1.0" encoding="UTF-8"?>', '<routes>']
    t, i = 0.0, 0
    while t < DURATA:
        if kind == "masini":
            s, d = rnd.choice(pairs)
            o.append('    <trip id="masina_%d" type="masina" depart="%.2f" from="%s" to="%s" departLane="best" departSpeed="max"/>' % (i, t, s, d))
        else:
            s, d = rnd.sample(edges, 2)
            o.append('    <person id="pieton_%d" type="pieton" depart="%.2f"><walk from="%s" to="%s"/></person>' % (i, t, s, d))
        t += period; i += 1
    o += ['</routes>', '']
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(o))
    return out


def car_graph(net):
    car = set(net.normal_edges("passenger"))
    succ = {e: [x for x in net.succ.get(e, ()) if x in car] for e in car}
    pred = {e: [] for e in car}
    for e in car:
        for x in succ[e]:
            pred[x].append(e)
    # noduri de margine: doar o strada (dus-intors) pentru masini -> intrari/iesiri din zona
    deg = {}
    for e in car:
        for j in (net.edges[e]["frm"], net.edges[e]["to"]):
            deg.setdefault(j, set()).add(e.lstrip("-"))
    fringe = set(j for j, s in deg.items() if len(s) == 1 or net.junctions.get(j) == "dead_end")
    src = [e for e in car if net.edges[e]["frm"] in fringe]
    dst = [e for e in car if net.edges[e]["to"] in fringe]
    return car, succ, pred, src, dst


def bfs(starts, g):
    seen = set(starts); st = list(starts)
    while st:
        e = st.pop()
        for x in g[e]:
            if x not in seen:
                seen.add(x); st.append(x)
    return seen


def check_network(net):
    car, succ, pred, src, dst = car_graph(net)
    # componenta principala: strazile care se pot atinge reciproc cu bulevardul cel mai lat
    # o strada e functionala daca se afla pe un drum de la o intrare la o iesire (alta strada)
    base = lambda e: e.lstrip("-").split("#")[0]
    F = {s: bfs([s], succ) for s in src}
    B = {d: bfs([d], pred) for d in dst}
    ok = set()
    for s in src:
        for d in dst:
            if base(d) != base(s) and d in F[s]:
                ok |= F[s] & B[d]
    bad = sorted(e for e in car if e not in ok)
    with open(os.path.join(DIR_RETEA, "verificare_retea.txt"), "w", encoding="utf-8") as f:
        f.write("Strazi pentru masini: %d, intrari/iesiri: %d/%d\n" % (len(car), len(src), len(dst)))
        f.write("Strazi fara legatura completa (%d):\n" % len(bad))
        for e in bad:
            f.write("  %s %s\n" % (e, net.edges[e]["name"]))
    log("  Verificare retea: %d strazi, %d intrari, %d fara legatura completa" % (len(car), len(src), len(bad)))
    return bad, ok


def fix_isolated(net):
    """Strazile care in OpenStreetMap nu sunt legate de nicio alta strada (doar de alei pietonale)
    primesc o legatura scurta, dus-intors, catre cea mai apropiata intersectie functionala."""
    bad, ok = check_network(net)
    if not bad:
        return net
    car, succ, pred, src, dst = car_graph(net)
    cands = sorted(ok, key=lambda e: -len(net.edges[e]["lanes"]))[:15]
    core = max((bfs([m], succ) & bfs([m], pred) for m in cands), key=len) if cands else ok
    okj = set()
    for e in core:   # doar intersectii din reteaua principala (se poate intra si iesi in ambele sensuri)
        okj.add(net.edges[e]["frm"]); okj.add(net.edges[e]["to"])
    okj = [j for j in okj if net.junctions.get(j) not in ("dead_end", None) and not j.startswith(":")]
    badj = set()
    for e in bad:
        badj.add(net.edges[e]["frm"]); badj.add(net.edges[e]["to"])
    links, done = [], set()
    for a in sorted(badj):
        if a in done:
            continue
        ax, ay = net.jxy[a]
        b = min(okj, key=lambda j: (net.jxy[j][0] - ax) ** 2 + (net.jxy[j][1] - ay) ** 2)
        d = math.hypot(net.jxy[b][0] - ax, net.jxy[b][1] - ay)
        links.append((d, a, b))
    links.sort()
    chosen, comps = [], []
    for d, a, b in links:   # o singura legatura pentru fiecare grup de strazi izolate
        comp = bfs([e for e in bad if net.edges[e]["frm"] == a or net.edges[e]["to"] == a],
                   {e: [x for x in net.succ.get(e, ()) if x in bad] for e in bad})
        if any(comp & c for c in comps) or d > 120:
            continue
        comps.append(comp); chosen.append((d, a, b))
    if not chosen:
        return net
    patch = os.path.join(DIR_RETEA, "legaturi_auto.edg.xml")
    with open(patch, "w", encoding="utf-8") as f:
        f.write("<edges>\n")
        for i, (d, a, b) in enumerate(chosen):
            for eid, x, y in (("legatura_%d" % i, a, b), ("-legatura_%d" % i, b, a)):
                f.write('    <edge id="%s" from="%s" to="%s" priority="2" numLanes="1" speed="8.33" '
                        'allow="passenger taxi delivery bicycle pedestrian emergency" name="acces (legatura automata)"/>\n' % (eid, x, y))
        f.write("</edges>\n")
    try:
        tmp = NET + ".tmp.xml"
        code, _ = run([binary("netconvert"), "-s", NET, "-e", patch, "-o", tmp, "--ignore-errors", "true",
                       "--walkingareas", "true"], os.path.join(DIR_RETEA, "netconvert.log"))
        if code == 0 and os.path.isfile(tmp):
            n2 = Net(tmp)
            bad2, _ = check_network(n2)
            if len(bad2) < len(bad) and len(n2.crossings) >= len(net.crossings) * 0.9:
                os.replace(tmp, NET)
                log("  Am legat %d strazi izolate de restul retelei" % len(chosen))
                return n2
        if os.path.exists(tmp):
            os.remove(tmp)
    except Exception as ex:
        log("  legaturi automate: %s" % ex)
    log("  Nu am putut lega automat strazile izolate (raman in verificare_retea.txt)")
    return net


# ---------------------------------------------------------------------------
# REGULI DE CIRCULATIE IN RETEA (tramvai cu prioritate, giratoriu, prioritate de dreapta)
# ---------------------------------------------------------------------------
def _clasa_muchie(e):
    cls = set()
    for l in e.findall("lane"):
        a = l.get("allow")
        cls |= set(a.split()) if a else {"passenger"}
    if "tram" in cls and "passenger" not in cls:
        return "tram"
    return "car" if "passenger" in cls or "emergency" in cls else "alt"


def _analiza_reguli():
    r = ET.parse(NET).getroot()
    edges = {e.get("id"): e for e in r.findall("edge") if not e.get("function")}
    inc = {}
    for e in edges.values():
        inc.setdefault(e.get("to"), []).append(e)
    jt = {j.get("id"): j.get("type") for j in r.findall("junction")}
    mari = ("highway.primary", "highway.secondary", "highway.tertiary", "highway.primary_link",
            "highway.secondary_link", "highway.tertiary_link", "highway.trunk")
    rbl_mari = [n for n, es in inc.items() if jt.get(n) == "right_before_left"
                and any(e.get("type") in mari or _clasa_muchie(e) == "tram" for e in es)]
    tram_jos = []   # (nod, muchii tramvai, prioritate maxima a strazilor)
    tram_ok = 0
    for n, es in inc.items():
        if jt.get(n) in ("traffic_light", "traffic_light_unregulated", "rail_signal", "rail_crossing"):
            continue
        tr = [e for e in es if _clasa_muchie(e) == "tram"]
        cars = [e for e in es if _clasa_muchie(e) == "car"]
        if not tr or not cars:
            continue
        pmax = max(int(e.get("priority", "0")) for e in cars)
        if min(int(e.get("priority", "0")) for e in tr) > pmax and jt.get(n) != "right_before_left":
            tram_ok += 1
        else:
            tram_jos.append((n, [e.get("id") for e in tr], pmax))
    rb = r.findall("roundabout")
    cnt = {}
    for t in jt.values():
        cnt[t] = cnt.get(t, 0) + 1
    ncr = sum(1 for e in r.findall("edge") if e.get("function") == "crossing")
    return dict(rbl_mari=rbl_mari, tram_jos=tram_jos, tram_ok=tram_ok, giratorii=len(rb), tipuri=cnt, treceri=ncr,
                semafoare=len(r.findall("tlLogic")))


def verifica_reguli():
    a = _analiza_reguli()
    t = a["tipuri"]
    lines = ["VERIFICARE REGULI DE CIRCULATIE (OUG 195/2002 + Regulament)",
             "",
             "Sens giratoriu (cine e in giratoriu are prioritate): %d giratorii recunoscute" % a["giratorii"],
             "Tramvai cu prioritate in intersectii nedirijate (art. 59): %d intersectii OK, %d de corectat"
             % (a["tram_ok"], len(a["tram_jos"])),
             "Intersectii cu semafor: %d (%d programe)" % (t.get("traffic_light", 0), a["semafoare"]),
             "Intersectii cu drum prioritar / cedeaza: %d" % t.get("priority", 0),
             "Intersectii cu prioritate de dreapta: %d" % t.get("right_before_left", 0),
             "Treceri de pietoni (pietonul are prioritate cand nu e semafor): %d" % a["treceri"],
             "",
             "Soferi: limita de viteza, stop pe rosu, nu blocheaza intersectia, cedeaza pietonilor si tramvaiului.",
             "Urgente: ambulanta / politie / pompieri cu girofar, ceilalti le fac loc.",
             "Setarile sunt in reguli_circulatie.py (RESPECTA_REGULILE = True)."]
    if a["giratorii"] == 0:
        lines.append("ATENTIE: giratoriul nu a fost recunoscut automat.")
    for n, tr, p in a["tram_jos"]:
        lines.append("  de corectat: nod %s, cale tramvai %s (strada are prioritatea %d)" % (n, " ".join(tr), p))
    with open(os.path.join(DIR_RETEA, "verificare_reguli.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    log("  Reguli: %d giratorii, tramvai prioritar in %d intersectii (%d de corectat), %d semafoare, "
        "%d cu prioritate de dreapta, %d treceri" % (a["giratorii"], a["tram_ok"], len(a["tram_jos"]),
                                                    t.get("traffic_light", 0), t.get("right_before_left", 0), a["treceri"]))
    return a


def aplica_reguli_retea(net):
    log("\n[1b] Aplic regulile de circulatie in retea ...")
    a = verifica_reguli()
    if not a["tram_jos"] and not a["rbl_mari"]:
        return net
    # art. 59: tramvaiul are prioritate in intersectiile nedirijate -> cale de rulare mai prioritara decat strada
    ep = os.path.join(DIR_RETEA, "reguli_tramvai.edg.xml")
    np_ = os.path.join(DIR_RETEA, "reguli_tramvai.nod.xml")
    done = set()
    with open(ep, "w", encoding="utf-8") as f, open(np_, "w", encoding="utf-8") as g:
        f.write("<edges>\n")
        g.write("<nodes>\n")
        nodes = set(a["rbl_mari"])
        for n, tr, p in a["tram_jos"]:
            for e in tr:
                if e not in done:
                    f.write('    <edge id="%s" priority="%d"/>\n' % (e, max(17, p + 5)))
                    done.add(e)
            nodes.add(n)
        # bulevardele / strazile principale au drum prioritar (indicator), nu prioritate de dreapta
        for n in sorted(nodes):
            g.write('    <node id="%s" type="priority"/>\n' % n)
        f.write("</edges>\n")
        g.write("</nodes>\n")
    tmp = NET + ".reguli.xml"
    try:
        code, _ = run([binary("netconvert"), "-s", NET, "-e", ep, "-n", np_, "-o", tmp, "--ignore-errors", "true",
                       "--walkingareas", "true"], os.path.join(DIR_RETEA, "netconvert.log"))
        if code == 0 and os.path.isfile(tmp):
            n2 = Net(tmp)
            if len(n2.crossings) >= len(net.crossings):
                os.replace(tmp, NET)
                log("  Tramvaiul a primit prioritate in %d intersectii, %d intersectii de bulevard au drum prioritar"
                    % (len(a["tram_jos"]), len(a["rbl_mari"])))
                verifica_reguli()
                return n2
    except Exception as ex:
        log("  reguli tramvai: %s" % ex)
    if os.path.exists(tmp):
        os.remove(tmp)
    log("  Nu am putut corecta automat prioritatea tramvaiului (vezi retea/verificare_reguli.txt)")
    return net


def car_trips(net, lvl, period, seed):
    """calatorii intre toate intrarile/iesirile zonei (fiecare bulevard primeste trafic)"""
    rnd = random.Random(seed)
    car, succ, pred, src, dst = car_graph(net)
    reach = {s: bfs([s], succ) for s in set(src) | set(car)} if len(car) < 600 else None
    w = lambda e: len(net.edges[e]["lanes"])
    fpairs = [(s, d) for s in src for d in dst if d != s and d.lstrip("-") != s.lstrip("-") and (reach is None or d in reach[s])]
    allc = sorted(car)
    if not fpairs:
        return None
    fw = [w(s) * w(d) for s, d in fpairs]
    raw = os.path.join(DIR_TRAFIC, "_masini_%s_brut.trips.xml" % lvl)
    out = os.path.join(DIR_TRAFIC, "masini_%s.trips.xml" % lvl)
    o = ['<?xml version="1.0" encoding="UTF-8"?>', '<routes>']
    t, i = 0.0, 0
    while t < DURATA:
        # toate masinile intra si ies pe la marginea zonei (fara aparitii in mijlocul intersectiilor)
        s, d = rnd.choices(fpairs, weights=fw)[0]
        o.append('    <trip id="masina_%d" type="masina" depart="%.2f" from="%s" to="%s" departLane="best" departSpeed="max"/>' % (i, t, s, d))
        t += rnd.expovariate(1.0 / period); i += 1
    o += ['</routes>', '']
    with open(raw, "w", encoding="utf-8") as f:
        f.write("\n".join(o))
    try:
        cmd = [binary("duarouter"), "-n", NET, "-r", raw, "-a", os.path.join(DIR_TRAFIC, "tipuri_masini_%s.add.xml" % lvl),
               "-o", out, "--vtype-output", os.path.join(DIR_TRAFIC, "_tipuri_temp.xml"), "--write-trips", "true", "--ignore-errors", "true", "--no-warnings", "true", "--no-step-log", "true"]
        code, _ = run(cmd, os.path.join(DIR_TRAFIC, "randomTrips.log"))
        if code == 0 and os.path.isfile(out):
            return out
    except Exception as ex:
        log("    duarouter: %s" % ex)
    shutil.copy(raw, out)
    return out


def gen_nivel(net, k, lvl, fm=1.0, fp=1.0):
    """genereaza masinile, pietonii si urgentele unui nivel; fm/fp = factori de calibrare"""
    P = NIVELURI[lvl]
    for kind, per_h in (("masini", P["masini_h"] * fm), ("pietoni", P["pietoni_h"] * fp)):
        period = 3600.0 / max(1.0, per_h)
        r = car_trips(net, lvl, period, 42 + k) if kind == "masini" else random_trips(lvl, kind, period, 42 + k)
        if r is None:
            fallback_trips(net, lvl, kind, period, 42 + k)
    return RC.scrie_urgente(os.path.join(DIR_TRAFIC, "urgente_%s.rou.xml" % lvl),
                            RC.perechi_din_trips(os.path.join(DIR_TRAFIC, "masini_%s.trips.xml" % lvl)),
                            RC.URGENTE_H.get(lvl, 3), DURATA, 77 + k)


def build_demand(net):
    log("\n[5/7] Generez traficul de masini si pietoni pentru fiecare nivel ...")
    write_vtypes()
    RC.scrie_tipuri_urgenta(os.path.join(DIR_TRAFIC, "tipuri_urgenta.add.xml"))
    lf = os.path.join(DIR_TRAFIC, "randomTrips.log")
    if os.path.exists(lf):
        os.remove(lf)
    for k, (lvl, P) in enumerate(NIVELURI.items()):
        nu = gen_nivel(net, k, lvl)
        log("  %-15s masini %4d/h  pietoni %4d/h  tramvai la %3d s  urgente %d" % (
            P["nume"], P["masini_h"], P["pietoni_h"], P["tram_interval"], nu))


def calibreaza(net, max_incercari=6):
    """ruleaza fiecare nivel fara GUI; daca apar teleportari / coliziuni / pietoni blocati,
    reduce cererea nivelului respectiv si reincearca, pana cand simularea e curata"""
    import verificare_sim as V
    log("\n[6/7] Verific fiecare nivel in SUMO (fara teleportari, coliziuni sau pietoni blocati) ...")
    log("  (poate dura cateva minute)")
    lvls = list(NIVELURI)
    st = {l: dict(factor_masini=1.0, factor_pietoni=1.0, ok=False) for l in lvls}
    rosu = True
    if os.path.exists(V.CALIBRARE):
        os.remove(V.CALIBRARE)
    for it in range(1, max_incercari + 1):
        todo = [l for l in lvls if not st[l]["ok"] and not st[l].get("eroare")]
        if not todo:
            break
        cfgs = {}
        for l in todo:
            cfgs[l] = os.path.join(DIR_SCEN, "_test_%s.sumocfg" % l)
            write_sumocfg(cfgs[l], l, l, l, satelit=False)
        workers = max(1, min(len(todo), (os.cpu_count() or 2) - 1))
        with ThreadPoolExecutor(max_workers=workers) as ex:
            res = dict(zip(todo, ex.map(lambda l: V.ruleaza_test(cfgs[l], l), todo)))
        col_total = 0
        for l in todo:
            r, s = res[l], st[l]
            s.update(teleport=r["teleport"], coliziuni=r["coliziuni"], blocati=r["blocati"], unde=r["unde"])
            log("  incercarea %d  %-15s teleportari %3s  coliziuni %3s  pietoni blocati %3s  (masini x%.2f, pietoni x%.2f)%s"
                % (it, NIVELURI[l]["nume"], r["teleport"], r["coliziuni"], r["blocati"], s["factor_masini"],
                   s["factor_pietoni"], "  OK" if r["ok"] else ""))
            if r["ok"]:
                s["ok"] = True
                continue
            if r.get("eroare") or (r.get("cod") not in (0, None)):
                s["eroare"] = r.get("eroare") or "sumo a iesit cu codul %s" % r.get("cod")
                log("    eroare la rulare (%s) - vezi rezultate/_test_%s.log" % (s["eroare"], l))
                continue
            if r["unde"]:
                log("    probleme la: " + ", ".join("%s (%d)" % kv for kv in r["unde"]))
            col_total += r["coliziuni"]
            if r["teleport"] > 0 or r["coliziuni"] > 0:
                s["factor_masini"] = max(0.3, s["factor_masini"] * 0.85)
            if r["blocati"] > 0:
                s["factor_pietoni"] = max(0.3, s["factor_pietoni"] * 0.85)
        if col_total and rosu:
            # urgentele nu mai trec pe rosu (asteapta verdele, dar au in continuare prioritate)
            rosu = False
            RC.scrie_tipuri_urgenta(os.path.join(DIR_TRAFIC, "tipuri_urgenta.add.xml"), trece_pe_rosu=False)
            log("    vehiculele de urgenta nu mai trec pe rosu (evita coliziunile)")
        if it < max_incercari:
            for k, l in enumerate(lvls):
                if l in todo and not st[l]["ok"] and not st[l].get("eroare"):
                    gen_nivel(net, k, l, st[l]["factor_masini"], st[l]["factor_pietoni"])
    for l in lvls:
        st[l]["urgente_trec_pe_rosu"] = rosu
    V.scrie_calibrare(st)
    for l in lvls:
        if os.path.exists(os.path.join(DIR_SCEN, "_test_%s.sumocfg" % l)):
            os.remove(os.path.join(DIR_SCEN, "_test_%s.sumocfg" % l))
    bune = [NIVELURI[l]["nume"] for l in lvls if st[l]["ok"]]
    rele = [NIVELURI[l]["nume"] for l in lvls if not st[l]["ok"]]
    log("  Niveluri verificate (fara teleportari si coliziuni): %s" % (", ".join(bune) or "niciunul"))
    if rele:
        log("  ATENTIE: inca au probleme: %s - trimite construieste.log si rezultate/_test_*.log" % ", ".join(rele))
    return st


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fara-satelit", action="store_true", help="nu descarca imaginea satelit")
    ap.add_argument("--google-key", default=os.environ.get("GOOGLE_MAPS_KEY"),
                    help="cheie Google Maps Static API -> imagine satelit Google (altfel Esri World Imagery)")
    ap.add_argument("--zoom", type=int, default=19, help="nivel zoom imagine satelit (18-20)")
    ap.add_argument("--doar-trafic", action="store_true", help="nu regenera reteaua, doar traficul")
    ap.add_argument("--fara-verificare", action="store_true", help="nu rula verificarea automata in SUMO")
    a = ap.parse_args()
    mkdirs()
    log("SUMO_HOME = %s" % sumo_home())
    if not (a.doar_trafic and os.path.isfile(NET)):
        build_net()
    net = Net(NET)
    if not a.doar_trafic:
        net = fix_isolated(net)
        net = aplica_reguli_retea(net)
    else:
        check_network(net)
        verifica_reguli()
    osm_root = ET.parse(OSM).getroot()
    gimg = os.path.join(DIR_SAT, "google_podu_ros.png")
    gjson = os.path.join(DIR_SAT, "google_podu_ros.json")
    if os.path.isfile(gimg) and os.path.isfile(gjson) and not a.fara_satelit:
        # imaginea Google Maps trimisa de utilizator, deja aliniata pe coordonatele retelei
        import json
        d = json.load(open(gjson))
        if "utm_centerX" in d:
            # coordonate UTM absolute -> coordonatele retelei curente (netOffset depinde de map.osm)
            d["centerX"] = d["utm_centerX"] + net.offset[0]
            d["centerY"] = d["utm_centerY"] + net.offset[1]
        decals = ['        <decal file="%s" centerX="%.2f" centerY="%.2f" width="%.2f" height="%.2f" '
                  'rotation="0.00" layer="-1.00" screenRelative="0"/>' % (gimg, d["centerX"], d["centerY"], d["width"], d["height"])]
        log("\n[2/7] Fundal: imaginea Google Maps (satelit/google_podu_ros.png)")
    else:
        decals = [] if a.fara_satelit else build_satellite(net, a.zoom, a.google_key)
    write_gui_settings(net, decals)
    build_crossings(net)
    build_trams(net, osm_root)
    build_demand(net)
    if not a.fara_verificare:
        calibreaza(net)
    log("\n[7/7] Scriu scenariile (.sumocfg) ...")
    for lvl in NIVELURI:
        write_sumocfg(os.path.join(DIR_SCEN, "%s.sumocfg" % lvl), lvl, lvl, lvl, satelit=bool(decals))
        log("  scenarii/%s.sumocfg" % lvl)
    try:
        import ora_reala
        ora_reala.tipuri()
        b, e, ok, _plan, _cnt = ora_reala.genereaza_verificat(ora_reala.ora_iasi(), 3, verifica=not a.fara_verificare, log=log)
        ora_reala.write_cfg(b, e, ora_reala.gui_settings(False), verificat=ok)
        log("  scenarii/ora_reala.sumocfg (de acum, 3 ore)")
    except Exception as ex:
        log("  ora_reala: %s" % ex)
    with open(os.path.join(ROOT, "construieste.log"), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG))
    log("\nGATA! Porneste simularea cu  ruleaza.bat  (sau: python simuleaza.py --nivel ora_de_varf)")


if __name__ == "__main__":
    try:
        main()
    except Exception as ex:
        import traceback
        traceback.print_exc()
        with open(os.path.join(ROOT, "construieste.log"), "w", encoding="utf-8") as f:
            f.write("\n".join(LOG) + "\n\nEROARE: %s\n" % traceback.format_exc())
        sys.exit(1)

# -*- coding: utf-8 -*-
"""
Verificarea automata a simularii: ruleaza SUMO fara fereastra si numara
teleportarile, coliziunile si pietonii blocati. construieste.py si ora_reala.py
folosesc rezultatul ca sa reduca cererea pana cand simularea merge curat.
"""
from __future__ import print_function
import os
import re
import json
import subprocess

from podu_lib import DIR_TRAFIC, DIR_REZ, binary

CALIBRARE = os.path.join(DIR_TRAFIC, "calibrare.json")
TELEPORT_TEST = 300      # in test: daca un vehicul asteapta 300 s, e considerat blocaj


def citeste_calibrare():
    try:
        return json.load(open(CALIBRARE, encoding="utf-8"))
    except Exception:
        return {}


def scrie_calibrare(d):
    with open(CALIBRARE, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=1)


def factor(nivel, tip):
    """factorul de cerere calibrat (1.0 daca nu a fost calibrat)"""
    return float(citeste_calibrare().get(nivel, {}).get("factor_" + tip, 1.0))


def verificat(nivel):
    return bool(citeste_calibrare().get(nivel, {}).get("ok"))


def _attr(txt, tag, name):
    m = re.search(r"<%s\b[^>]*\b%s=\"([\d.]+)\"" % (tag, name), txt)
    return int(float(m.group(1))) if m else None


def ruleaza_test(cfg, eticheta, timeout=1800):
    """ruleaza sumo (fara GUI) pe cfg; intoarce dict cu teleport / coliziuni / pietoni blocati"""
    if not os.path.isdir(DIR_REZ):
        os.makedirs(DIR_REZ)
    stat = os.path.join(DIR_REZ, "_test_%s_stat.xml" % eticheta)
    logf = os.path.join(DIR_REZ, "_test_%s.log" % eticheta)
    for p in (stat, logf):
        if os.path.exists(p):
            os.remove(p)
    cmd = [binary("sumo"), "-c", cfg, "--time-to-teleport", str(TELEPORT_TEST), "--statistic-output", stat,
           "--log", logf, "--no-step-log", "true", "--duration-log.disable", "true",
           "--summary-output", os.path.join(DIR_REZ, "_test_%s_sumar.xml" % eticheta),
           "--tripinfo-output", os.path.join(DIR_REZ, "_test_%s_calatorii.xml" % eticheta)]
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
        code = p.returncode
    except subprocess.TimeoutExpired:
        return dict(ok=False, eroare="timeout", teleport=-1, coliziuni=-1, blocati=-1, unde=[])
    for extra in ("sumar", "calatorii"):
        q = os.path.join(DIR_REZ, "_test_%s_%s.xml" % (eticheta, extra))
        if os.path.exists(q):
            try:
                os.remove(q)
            except OSError:
                pass
    txt = open(stat, encoding="utf-8", errors="replace").read() if os.path.isfile(stat) else ""
    log = open(logf, encoding="utf-8", errors="replace").read() if os.path.isfile(logf) else ""
    tel = _attr(txt, "teleports", "total")
    col = _attr(txt, "safety", "collisions")
    jam = _attr(txt, "persons", "jammed")
    # rezerva: numaram mesajele din log
    if tel is None:
        tel = len(re.findall(r"Teleporting vehicle", log))
    if col is None:
        col = len(re.findall(r"collision", log))
    nj = len(re.findall(r"is jammed", log))
    jam = max(jam or 0, nj)
    unde = {}
    for m in re.finditer(r"(Teleporting vehicle|collision|is jammed)[^\n]*?(?:lane|edge)='([^']+)'", log):
        k = m.group(2).lstrip(":").rsplit("_", 1)[0]
        unde[k] = unde.get(k, 0) + 1
    top = sorted(unde.items(), key=lambda kv: -kv[1])[:8]
    return dict(ok=(code == 0 and tel == 0 and col == 0 and jam == 0), cod=code, teleport=tel, coliziuni=col,
                blocati=jam, unde=top)

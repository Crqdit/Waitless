@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === Construiesc proiectul SUMO Podu Ros (retea, satelit, tramvaie, trafic) ===
where py >nul 2>nul
if %errorlevel%==0 (py -3 construieste.py %*) else (python construieste.py %*)
echo.
echo Jurnalul complet este in construieste.log
pause

@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py -3 ora_reala.py --meniu %*) else (python ora_reala.py --meniu %*)
pause

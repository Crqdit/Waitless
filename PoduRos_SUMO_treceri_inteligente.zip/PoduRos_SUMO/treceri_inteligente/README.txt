SMART PEDESTRIAN CROSSINGS ON TOP OF THE PODU ROS SIMULATION
=============================================================

START
   Double-click  treceri_inteligente.bat  (in the main PoduRos_SUMO folder),
   or run:  python treceri_inteligente\smart_gui.py

   Needs what the rest of the project already needs: Python 3 and SUMO (SUMO_HOME set, or
   "pip install eclipse-sumo"). TraCI comes with SUMO. tkinter comes with Python on Windows.
   The first time, the program builds retea\podu_ros_ctl.net.xml by itself (a few seconds).

THE WINDOW
   Left side - build a setup
     * Traffic level (liber ... ambuteiaj) and "Traffic x" (1.25 = 25 % more cars and people).
     * As-is = the model exactly as it was (zebras + original signals).
     * Smart crossings = your system: pressure plates, countdown 25 s - 2 s per person (min 10 s),
       in-road sensors, and the rule for cars already on the sensors when the countdown ends:
       No hold / Hold, 60 s total cap / Hold, 12 s cap.
     * Tick any combination of fixes (list below).
     * "Run in SUMO-GUI" opens sumo-gui and runs that setup live. The table under the button shows
       every smart crossing: signal state, countdown, people waiting, people on the crossing, and
       for the B crossings how full the turn area is. In sumo-gui every smart crossing has a coloured
       dot: green = cars go, yellow = countdown / waiting / amber, red = all red, white = WALK,
       orange = clearing. "Delay ms" slows sumo-gui down (you can also change it inside sumo-gui).

   Right side - compare setups
     * "Add this setup to the comparison" puts the setup from the left side into the list.
       "Add presets" adds as-is, your system, + fix 5, + the new fixes, and everything together.
       The list is remembered between sessions (setups.json).
     * Simulated minutes = how long each run lasts. Repeats (seeds) = how many times each setup is run
       with different random driver/walker behaviour; every setup gets the same seeds and traffic.
       Parallel runs = how many simulations run at once (default: number of CPU cores - 1).
     * The table shows the mean and the spread (±) over the repeats; ★ marks the best value.
       It is saved to rezultate\treceri_inteligente\comparatie_<date>.txt and .csv.
     * IMPORTANT: Podu Ros is chaotic at rush hour - one run can tip into a jam and another not.
       A difference smaller than the ± spread is probably chance. Use 5-10 repeats before deciding.
     * Car demand is only generated for the first 60 minutes; 30-60 minutes is a good run length.

THE FIXES
   Fix 2   End the walk early when the crossing is empty (min 5 s walk, 1 s clearance).
   Fix 3   Line up B's walk with A's: B waits up to 5 s if A's walk is about to start.
   Fix 4   Wait for a gap in traffic: sensor 0 (25-60 m before the turn) must be empty 2.5 s,
           wait at most 4 s.
   Fix 5   Coordinated, storage-aware (as specified): learns the turning rate from sensor 2
           (last 3 minutes), starts B's walk only if the chance that more turners arrive than fit
           between the main road and the crossing is under 10 %, else waits up to 8 s for a safer
           moment; pulls A's walk forward if A is due within 15 s so both run together; ends walks
           early when the crossing is empty; stops new walkers if the turn area fills up.
   NEW - suggestions after running the model:
   Fix 6   Empty road, walk now. If no car is within 60 m of the crossing, the countdown is skipped
           and the walk starts 2 s after someone steps on the plate. The countdown exists to protect
           traffic; when there is no traffic it only makes people wait (and tempts them to cross on red).
   Fix 7   Smart clearance. Instead of a fixed 4 s clearance, cars stay red exactly until the
           crossing is empty (at least 1 s, at most 10 s). Faster when people cross quickly, safer
           when a slow walker is still on the road.
   Fix 8   Max wait guarantee. Nobody waits more than 45 s: once the first person on the plate has
           waited 45 s, holds, smart waits (fix 5) and gap waits (fix 4) are skipped. Without it, the
           car-friendly rules can stack up (countdown + hold + smart wait), and long waits are
           exactly what makes people cross on red.
   Fix 1 (move crossing B two car lengths up the side road) needs a change to the street network,
   so it is not offered.

WHERE THE SYSTEM IS INSTALLED (and why)
   I looked for places where cars that turn off a lane shared with straight traffic must then
   cross a pedestrian crossing a short distance later. At Podu Ros this is mostly cars leaving the
   roundabout: they share the outer lane with cars going round, so a stopped exiting car can block
   the cars behind it.
     North   B = Podu Ros just after the Bd. Regele Ferdinand left turn (only ~12 m = 1-2 cars of
             space; lane 3 is shared by straight and left-turning cars). A = Bd. Mangeron.
             This is the closest match to your T-junction, but very few people use B in the model.
     South   B = Str. Nicolina exit from the roundabout (~87 m of space), A = Nicolina entry.
     West    B = Sos. Nationala exit, C4 (~63 m). A zebra in the model -> made into a signal.
             This is where most collisions happen in the original model.
     East    B = Bd. Regele Mihai I exit, C5 (~84 m). A zebra in the model -> made into a signal.
   The two other crossings on the north signal (Podu Ros C1) run your basic plate rule.
   Bd. Socola (C6) also fits, but there a single crossing covers both directions, so A and B
   cannot be separated; it is left as it is.
   The "space" is measured as driving distance from where turners leave the shared lane to the
   crossing (the map has many 0.2 m pieces of road, so edge lengths are misleading).

WHAT IS SIMULATED, AND WHAT IS SIMPLIFIED
   * Plates count perfectly (a person standing 1 s on the plate = 1 person). The tile/weight logic
     from crossing_sim.py is not simulated; SUMO walkers have no weight or feet.
   * Sensors are simulated from car positions: sensor 1 = last 25 m of the shared lane before the
     turn, sensor 2 / turn area = between the turn and crossing B, sensor 0 = 25-60 m before the turn.
   * North junction: the original program is "actuated" and has an all-red pedestrian phase every
     cycle. With smart crossings it runs the same car phases with fixed times (36/3/29/3/3 s,
     the averages measured from the original), without the all-red pedestrian phase, because the
     crossings now get their walk from the plates. So "as-is vs smart" also contains this change;
     "smart vs smart + fixes" does not.
   * Cars yield to people still on a crossing when their light turns green again.
   * SUMO walkers: there are two 0.75 m footpaths next to crossing C1 where walkers going opposite
     ways deadlock until SUMO's "jam time" lets them pass (default 300 s). That made results
     depend on luck, so every run here (as-is included) uses a jam time of 20 s.
   * People in SUMO never cross on red, so the "waits over 45 s" line is the closest thing to
     "people who would give up and cross".

WHAT I FOUND WHEN I RAN IT
   Level "aglomerat", 30 simulated minutes, 3 repeats (report in rezultate\treceri_inteligente\
   comparatie_20261017_134523.txt):

                                        As-is   Your system   + fix 5   + fix 6,7,8   + fix 5,6,7,8
   Cars: avg time loss (s)              18.1       20.0         18.5       18.9          18.3
   Collisions                           10.3        3.0          2.0        2.3           1.3
   People: avg wait at crossings (s)    12.9       18.9         18.6        8.3           8.2
   People: waits over 45 s               4.7        0.0          1.3        0.0           0.0
   People: avg time loss per trip (s)   81.6      103.5        104.3       81.7          81.9

   * Your system cuts collisions a lot (C4 and C5 become signals) but costs cars ~2 s and makes
     people wait longer than at the original zebras.
   * Fix 5 wins back most of the car delay (20.0 -> 18.5 s), mainly through shared A+B walks at
     Nicolina. It does not shorten pedestrian waits.
   * Fixes 6, 7, 8 more than halve the pedestrian wait (18.9 -> 8.3 s) and bring pedestrian time
     loss back to the as-is level, with no clear cost to cars.
   * All four together (fix 5 + 6 + 7 + 8) was the best all-round setup in this test.
   * The "turner blocks straight traffic" problem itself is rare in this model: the model's own
     check reduced car demand to 38 % of the nominal values, and the roundabout exits have room
     for 8-12 cars. At ora_de_varf, an earlier 3-repeat test of fix 5 was mixed (one run tipped
     into a jam, the others were normal) - run 5-10 repeats there before concluding anything.

FILES
   treceri_inteligente\smart_gui.py      the window
   treceri_inteligente\smart_crossing.py the controller (rules, sensors, measurements). All settings
                                         are at the top, with the same names as in crossing_sim.py.
                                         Also runs alone:
       python treceri_inteligente\smart_crossing.py --level ora_de_varf --minutes 30 --seed 2
              --config "{\"hold\": \"cap12\", \"fix5\": true}"   [--gui]  [--out result.json]
   retea\podu_ros_ctl.net.xml            the network with C4 and C5-east signalised (rebuilt
                                         automatically if podu_ros.net.xml changes)
   rezultate\treceri_inteligente\        all run outputs and comparison reports

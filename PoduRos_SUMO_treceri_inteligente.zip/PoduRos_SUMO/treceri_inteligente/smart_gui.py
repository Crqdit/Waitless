#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Smart crossings for Podu Ros - control window.

  Left:  build a setup (hold rule + fixes) and watch it live in sumo-gui.
  Right: put several setups in a list, choose how many simulated minutes and how many
         repeats (seeds), and compare them side by side. Results are saved to
         rezultate/treceri_inteligente/.

Run:  python treceri_inteligente/smart_gui.py      (or double-click treceri_inteligente.bat)
"""
from __future__ import print_function
import csv, datetime, json, math, os, queue, statistics, subprocess, sys, threading, time
import tkinter as tk
from tkinter import ttk, messagebox

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import smart_crossing as SC     # noqa: E402

SETUPS_FILE = os.path.join(HERE, 'setups.json')
LEVELS = list(SC.NIVELURI.keys())
PRESETS = [
    ('As-is (original model)', dict(smart=False)),
    ('Your system (12 s hold)', dict(smart=True, hold='cap12')),
    ('Your system + fix 5', dict(smart=True, hold='cap12', fix5=True)),
    ('Your system + new fixes 6, 7, 8', dict(smart=True, hold='cap12', fix6=True, fix7=True, fix8=True)),
    ('Fix 5 + 6 + 7 + 8', dict(smart=True, hold='cap12', fix5=True, fix6=True, fix7=True, fix8=True)),
]
# rough seconds of computer time per simulated minute (one core); only for the estimate
SEC_PER_MIN = {'liber': 0.3, 'relativ_liber': 0.4, 'semi_aglomerat': 0.5, 'aglomerat': 0.7,
               'ora_de_varf': 1.2, 'ambuteiaj': 2.5}


def full_cfg(cfg):
    c = dict(SC.DEFAULT_CONFIG)
    c.update(cfg)
    return c


class App(object):
    def __init__(self, root):
        self.root = root
        root.title('Podu Ros - smart pedestrian crossings')
        root.geometry('1300x880')
        self.q = queue.Queue()
        self.live_stop = None
        self.cmp_stop = None
        self.setups = self.load_setups()

        outer = ttk.PanedWindow(root, orient='horizontal')
        outer.pack(fill='both', expand=True)
        left = ttk.Frame(outer, padding=8)
        right = ttk.Frame(outer, padding=8)
        outer.add(left, weight=2)
        outer.add(right, weight=3)
        self.build_left(left)
        self.build_right(right)
        root.after(150, lambda: outer.sashpos(0, 560))
        self.root.after(200, self.poll)

    # ------------------------------------------------------------------ setup editor + live run
    def build_left(self, p):
        f = ttk.LabelFrame(p, text='Traffic', padding=6)
        f.pack(fill='x')
        ttk.Label(f, text='Level').grid(row=0, column=0, sticky='w')
        self.level = tk.StringVar(value='aglomerat')
        ttk.Combobox(f, textvariable=self.level, values=LEVELS, state='readonly', width=16).grid(row=0, column=1, sticky='w')
        ttk.Label(f, text='  Traffic x').grid(row=0, column=2, sticky='e')
        self.scale = tk.DoubleVar(value=1.0)
        ttk.Spinbox(f, from_=0.5, to=2.0, increment=0.05, textvariable=self.scale, width=6).grid(row=0, column=3, sticky='w')

        f = ttk.LabelFrame(p, text='Setup', padding=6)
        f.pack(fill='x', pady=6)
        self.smart = tk.BooleanVar(value=True)
        ttk.Radiobutton(f, text='As-is (original model: zebras + original signals)', variable=self.smart,
                        value=False, command=self.toggle).pack(anchor='w')
        ttk.Radiobutton(f, text='Smart crossings (pressure plates + sensors)', variable=self.smart,
                        value=True, command=self.toggle).pack(anchor='w')
        hf = ttk.Frame(f)
        hf.pack(fill='x', padx=18, pady=(4, 2))
        ttk.Label(hf, text='Cars already on the sensors when the countdown ends:').pack(anchor='w')
        self.hold = tk.StringVar(value='cap12')
        self.smart_widgets = []
        for k, v in SC.HOLD_MODES.items():
            w = ttk.Radiobutton(hf, text=v, variable=self.hold, value=k)
            w.pack(anchor='w', padx=10)
            self.smart_widgets.append(w)
        ttk.Label(f, text='Fixes (any combination):').pack(anchor='w', padx=18, pady=(6, 0))
        self.fix = {}
        for k, desc in SC.FIXES.items():
            v = tk.BooleanVar(value=False)
            w = tk.Checkbutton(f, text='%s - %s' % (k.replace('fix', 'Fix '), desc), variable=v,
                               wraplength=440, justify='left', anchor='w')
            w.pack(anchor='w', padx=28, fill='x')
            self.fix[k] = v
            self.smart_widgets.append(w)
        ttk.Label(f, text='(Fix 1 - moving crossing B up the side road - needs a change to the street '
                          'network, so it is not offered here.)', foreground='gray', wraplength=470).pack(anchor='w', padx=18, pady=(4, 0))

        bf = ttk.Frame(p)
        bf.pack(fill='x', pady=4)
        ttk.Button(bf, text='Add this setup to the comparison  →', command=self.add_current).pack(side='left')

        f = ttk.LabelFrame(p, text='Watch it live (sumo-gui)', padding=6)
        f.pack(fill='both', expand=True, pady=6)
        r = ttk.Frame(f)
        r.pack(fill='x')
        ttk.Label(r, text='Minutes').pack(side='left')
        self.live_min = tk.IntVar(value=70)
        ttk.Spinbox(r, from_=1, to=120, textvariable=self.live_min, width=5).pack(side='left', padx=4)
        ttk.Label(r, text='Delay ms').pack(side='left')
        self.delay = tk.IntVar(value=50)
        ttk.Spinbox(r, from_=0, to=1000, increment=10, textvariable=self.delay, width=5).pack(side='left', padx=4)
        self.live_btn = ttk.Button(r, text='▶ Run in SUMO-GUI', command=self.live)
        self.live_btn.pack(side='left', padx=6)
        ttk.Button(r, text='■ Stop', command=self.stop_live).pack(side='left')
        self.live_time = ttk.Label(f, text='')
        self.live_time.pack(anchor='w', pady=(4, 0))
        cols = ('state', 'people', 'on', 'cars')
        self.live_tree = ttk.Treeview(f, columns=cols, height=8)
        self.live_tree.heading('#0', text='Crossing')
        self.live_tree.column('#0', width=190)
        for c, t, w in zip(cols, ('Signal', 'Wait', 'On', 'Turn sensors'), (120, 40, 35, 125)):
            self.live_tree.heading(c, text=t)
            self.live_tree.column(c, width=w, anchor='w')
        self.live_tree.pack(fill='both', expand=True)
        ttk.Label(f, text='In sumo-gui each smart crossing has a dot: green = cars go, yellow = countdown / '
                          'waiting / amber, red = all red, white = WALK, orange = clearing.',
                  foreground='gray', wraplength=470).pack(anchor='w')
        self.toggle()

    def toggle(self):
        on = self.smart.get()
        for w in self.smart_widgets:
            if isinstance(w, tk.Checkbutton):
                w.config(state='normal' if on else 'disabled')
            else:
                w.state(['!disabled' if on else 'disabled'])

    def current_cfg(self):
        if not self.smart.get():
            return dict(smart=False)
        c = dict(smart=True, hold=self.hold.get())
        for k, v in self.fix.items():
            c[k] = bool(v.get())
        return c

    def live(self):
        if self.live_stop is not None:
            messagebox.showinfo('Running', 'A live run is already open.')
            return
        cfg = self.current_cfg()
        self.live_stop = threading.Event()
        self.live_btn.state(['disabled'])
        args = (cfg, self.level.get(), float(self.live_min.get()), float(self.scale.get()), int(self.delay.get()))
        threading.Thread(target=self.live_worker, args=args, daemon=True).start()

    def live_worker(self, cfg, level, minutes, scale, delay):
        try:
            ctl = SC.Controller(cfg)
            res = ctl.run(level, minutes, 1, scale, tag='live_%d' % int(time.time()), gui=True,
                          status_cb=lambda t, rows: self.q.put(('live', t, rows)),
                          stop_flag=self.live_stop, delay=delay)
            self.q.put(('live_done', res, cfg))
        except Exception as e:      # sumo-gui closed by the user, etc.
            self.q.put(('live_done', None, str(e)))

    def stop_live(self):
        if self.live_stop is not None:
            self.live_stop.set()

    # ------------------------------------------------------------------ comparison
    def build_right(self, p):
        f = ttk.LabelFrame(p, text='Setups to compare', padding=6)
        f.pack(fill='x')
        self.lst = tk.Listbox(f, height=7, selectmode='extended')
        self.lst.pack(side='left', fill='both', expand=True)
        bf = ttk.Frame(f)
        bf.pack(side='left', fill='y', padx=6)
        ttk.Button(bf, text='Remove', command=self.remove).pack(fill='x')
        ttk.Button(bf, text='Move up', command=lambda: self.move(-1)).pack(fill='x', pady=2)
        ttk.Button(bf, text='Load into editor', command=self.load_into_editor).pack(fill='x')
        ttk.Button(bf, text='Add presets', command=self.add_presets).pack(fill='x', pady=2)
        ttk.Button(bf, text='Clear', command=self.clear).pack(fill='x')
        self.refresh_list()

        f = ttk.LabelFrame(p, text='Compare', padding=6)
        f.pack(fill='x', pady=6)
        ttk.Label(f, text='Simulated minutes').grid(row=0, column=0, sticky='w')
        self.cmp_min = tk.IntVar(value=30)
        sp = ttk.Spinbox(f, from_=1, to=120, textvariable=self.cmp_min, width=6, command=self.estimate)
        sp.grid(row=0, column=1, sticky='w')
        ttk.Label(f, text='  Repeats (seeds)').grid(row=0, column=2, sticky='e')
        self.seeds = tk.IntVar(value=3)
        ttk.Spinbox(f, from_=1, to=20, textvariable=self.seeds, width=4, command=self.estimate).grid(row=0, column=3, sticky='w')
        ttk.Label(f, text='  Parallel runs').grid(row=0, column=4, sticky='e')
        self.workers = tk.IntVar(value=max(1, (os.cpu_count() or 2) - 1))
        ttk.Spinbox(f, from_=1, to=64, textvariable=self.workers, width=4, command=self.estimate).grid(row=0, column=5, sticky='w')
        bb = ttk.Frame(f)
        bb.grid(row=4, column=0, columnspan=8, sticky='w')
        self.go_btn = ttk.Button(bb, text='▶ Compare', command=self.compare)
        self.go_btn.pack(side='left')
        ttk.Button(bb, text='■ Stop', command=self.stop_cmp).pack(side='left', padx=6)
        self.est = ttk.Label(f, text='', foreground='gray')
        self.est.grid(row=1, column=0, columnspan=8, sticky='w', pady=(4, 0))
        ttk.Label(f, text='Traffic level and "Traffic x" are taken from the left panel. Every setup gets the same '
                          'traffic and the same seeds. Car demand is generated for the first 60 minutes.',
                  foreground='gray', wraplength=700).grid(row=2, column=0, columnspan=8, sticky='w')
        self.prog = ttk.Progressbar(f, mode='determinate')
        self.prog.grid(row=3, column=0, columnspan=8, sticky='ew', pady=4)
        f.columnconfigure(7, weight=1)
        for v in (self.cmp_min, self.seeds, self.workers):
            v.trace_add('write', lambda *a: self.estimate())
        self.level.trace_add('write', lambda *a: self.estimate())

        f = ttk.LabelFrame(p, text='Results (mean ± spread over repeats;  ★ = best)', padding=6)
        f.pack(fill='both', expand=True)
        self.res_tree = ttk.Treeview(f, show='headings')
        ys = ttk.Scrollbar(f, orient='vertical', command=self.res_tree.yview)
        xs = ttk.Scrollbar(f, orient='horizontal', command=self.res_tree.xview)
        self.res_tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        self.res_tree.grid(row=0, column=0, sticky='nsew')
        ys.grid(row=0, column=1, sticky='ns')
        xs.grid(row=1, column=0, sticky='ew')
        f.rowconfigure(0, weight=1)
        f.columnconfigure(0, weight=1)
        bf = ttk.Frame(p)
        bf.pack(fill='x')
        self.saved = ttk.Label(bf, text='', foreground='gray')
        self.saved.pack(side='left')
        ttk.Button(bf, text='Open results folder', command=self.open_folder).pack(side='right')
        self.estimate()

    def estimate(self):
        try:
            n = len(self.setups) * int(self.seeds.get())
            s = n * float(self.cmp_min.get()) * SEC_PER_MIN.get(self.level.get(), 1.0) * 2.0 \
                * float(self.scale.get()) / max(1, int(self.workers.get()))
            self.est.config(text='%d runs, roughly %s on this computer' % (
                n, ('%d min' % math.ceil(s / 60)) if s >= 60 else '%d s' % s))
        except (tk.TclError, ValueError):
            pass

    def load_setups(self):
        try:
            with open(SETUPS_FILE) as f:
                return [(n, c) for n, c in json.load(f)]
        except Exception:
            return [(n, dict(c)) for n, c in PRESETS[:3]]

    def save_setups(self):
        try:
            with open(SETUPS_FILE, 'w') as f:
                json.dump(self.setups, f, indent=1)
        except Exception:
            pass

    def refresh_list(self):
        self.lst.delete(0, 'end')
        for i, (n, c) in enumerate(self.setups):
            lab = SC.config_label(full_cfg(c))
            self.lst.insert('end', '[%d] %s' % (i + 1, n if n == lab else '%s   (%s)' % (n, lab)))
        self.save_setups()
        if hasattr(self, 'est'):
            self.estimate()

    def add_current(self):
        cfg = self.current_cfg()
        name = SC.config_label(full_cfg(cfg))
        if any(full_cfg(c) == full_cfg(cfg) for _, c in self.setups):
            messagebox.showinfo('Already there', 'This setup is already in the list.')
            return
        self.setups.append((name, cfg))
        self.refresh_list()

    def add_presets(self):
        for n, c in PRESETS:
            if not any(full_cfg(x) == full_cfg(c) for _, x in self.setups):
                self.setups.append((n, dict(c)))
        self.refresh_list()

    def remove(self):
        for i in sorted(self.lst.curselection(), reverse=True):
            del self.setups[i]
        self.refresh_list()

    def clear(self):
        self.setups = []
        self.refresh_list()

    def move(self, d):
        sel = self.lst.curselection()
        if not sel or sel[0] + d < 0:
            return
        i = sel[0]
        self.setups[i + d], self.setups[i] = self.setups[i], self.setups[i + d]
        self.refresh_list()
        self.lst.selection_set(i + d)

    def load_into_editor(self):
        sel = self.lst.curselection()
        if not sel:
            return
        c = full_cfg(self.setups[sel[0]][1])
        self.smart.set(c['smart'])
        self.hold.set(c['hold'])
        for k, v in self.fix.items():
            v.set(bool(c.get(k)))
        self.toggle()

    def compare(self):
        if self.cmp_stop is not None:
            return
        if not self.setups:
            messagebox.showinfo('Nothing to compare', 'Add at least one setup first.')
            return
        try:
            SC.build_ctl_net()
        except Exception as e:
            messagebox.showerror('Network', 'Could not build the controlled network:\n%s' % e)
            return
        level, minutes, scale = self.level.get(), float(self.cmp_min.get()), float(self.scale.get())
        if minutes > 70 and not messagebox.askyesno(
                'Long run', 'Traffic is only generated for the first 60 minutes, so the network empties '
                            'after that. Run %d minutes anyway?' % minutes):
            return
        stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        outdir = os.path.join(SC.RUNS, 'comparatie_%s' % stamp)
        os.makedirs(outdir)
        jobs = []
        for i, (name, cfg) in enumerate(self.setups):
            for s in range(1, int(self.seeds.get()) + 1):
                jobs.append((i, s, cfg, os.path.join(outdir, 'setup%d_seed%d.json' % (i, s))))
        self.cmp_stop = threading.Event()
        self.go_btn.state(['disabled'])
        self.prog.config(maximum=len(jobs), value=0)
        self.saved.config(text='Running %d simulations ...' % len(jobs))
        meta = dict(level=level, minutes=minutes, scale=scale, seeds=int(self.seeds.get()),
                    setups=list(self.setups), outdir=outdir, stamp=stamp)
        threading.Thread(target=self.cmp_worker, args=(jobs, meta, int(self.workers.get())), daemon=True).start()

    def cmp_worker(self, jobs, meta, workers):
        script = os.path.join(HERE, 'smart_crossing.py')
        flags = 0x08000000 if os.name == 'nt' else 0      # no console window on Windows
        pending, running, results, errors = list(jobs), [], {}, []
        while (pending or running) and not self.cmp_stop.is_set():
            while pending and len(running) < workers:
                i, s, cfg, out = pending.pop(0)
                cmd = [sys.executable, script, '--level', meta['level'], '--minutes', str(meta['minutes']),
                       '--seed', str(s), '--scale', str(meta['scale']), '--config', json.dumps(cfg), '--out', out]
                pr = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, creationflags=flags)
                running.append((pr, i, s, out))
            time.sleep(0.3)
            for item in list(running):
                pr, i, s, out = item
                if pr.poll() is None:
                    continue
                running.remove(item)
                try:
                    with open(out) as f:
                        results.setdefault(i, []).append(json.load(f))
                except Exception:
                    errors.append('setup %d seed %d: %s' % (i, s, pr.stderr.read().decode(errors='replace')[-400:]))
                self.q.put(('progress', len(jobs) - len(pending) - len(running)))
        for pr, *_ in running:
            pr.kill()
        self.q.put(('cmp_done', results, meta, errors, self.cmp_stop.is_set()))

    def stop_cmp(self):
        if self.cmp_stop is not None:
            self.cmp_stop.set()

    def show_results(self, results, meta, errors, stopped):
        names = [n for n, _ in meta['setups']]
        cols = ['metric'] + ['s%d' % i for i in range(len(names))]
        t = self.res_tree
        t.delete(*t.get_children())
        t.configure(columns=cols)
        t.heading('metric', text='Measure')
        t.column('metric', width=300, anchor='w', stretch=False)
        for i, n in enumerate(names):
            k = len(results.get(i, []))
            t.heading('s%d' % i, text='[%d] %s' % (i + 1, n if len(n) < 20 else n[:18] + '…'))
            t.column('s%d' % i, width=150, anchor='e', stretch=False)
        table = []
        for key, label, lower in SC.METRICS:
            means, cells = [], []
            for i in range(len(names)):
                vals = [r[key] for r in results.get(i, []) if isinstance(r.get(key), (int, float))
                        and not (isinstance(r[key], float) and math.isnan(r[key]))]
                m = statistics.mean(vals) if vals else None
                sd = statistics.stdev(vals) if len(vals) > 1 else 0.0
                means.append(m)
                cells.append((m, sd))
            best = None
            ok = [m for m in means if m is not None]
            if lower is not None and len(ok) > 1 and max(ok) != min(ok):
                best = min(ok) if lower else max(ok)
            row = [label]
            for m, sd in cells:
                if m is None:
                    row.append('-')
                else:
                    s = ('%.1f' % m) + ((' ±%.1f' % sd) if sd else '')
                    row.append(('★ ' if best is not None and m == best else '') + s)
            t.insert('', 'end', values=row)
            table.append((label, cells))
        # per-crossing waits
        crossings = sorted({c for rs in results.values() for r in rs for c in r.get('per_crossing_wait', {})})
        for c in crossings:
            row = ['  wait at ' + c]
            for i in range(len(names)):
                vals = [r['per_crossing_wait'][c][0] for r in results.get(i, []) if c in r.get('per_crossing_wait', {})]
                row.append('%.1f' % statistics.mean(vals) if vals else '-')
            t.insert('', 'end', values=row)
        self.save_report(table, crossings, results, meta, errors, stopped)
        if errors:
            messagebox.showwarning('Some runs failed', '\n\n'.join(errors[:5]))

    def save_report(self, table, crossings, results, meta, errors, stopped):
        names = [n for n, _ in meta['setups']]
        base = os.path.join(SC.RUNS, 'comparatie_%s' % meta['stamp'])
        with open(base + '.csv', 'w', newline='', encoding='utf-8') as f:
            w = csv.writer(f)
            w.writerow(['measure'] + sum([[n + ' mean', n + ' spread'] for n in names], []))
            for label, cells in table:
                w.writerow([label] + sum([['' if m is None else round(m, 3), round(sd, 3)] for m, sd in cells], []))
        lines = ['SMART CROSSINGS - PODU ROS - comparison %s' % meta['stamp'],
                 'Traffic level: %s   traffic x%.2f   %d simulated minutes   %d repeats (seeds 1..%d)%s' % (
                     meta['level'], meta['scale'], meta['minutes'], meta['seeds'], meta['seeds'],
                     '   (STOPPED EARLY)' if stopped else ''), '']
        for i, (n, c) in enumerate(meta['setups']):
            lines.append('  [%d] %s  =  %s   (%d runs)' % (i + 1, n, SC.config_label(full_cfg(c)), len(results.get(i, []))))
        lines.append('')
        wlab = max(len(l) for l, _ in table) + 2
        lines.append(' ' * wlab + ''.join('%16s' % ('[%d]' % (i + 1)) for i in range(len(names))))
        for label, cells in table:
            lines.append(label.ljust(wlab) + ''.join(
                '%16s' % ('-' if m is None else ('%.1f' % m) + (' ±%.1f' % sd if sd else '')) for m, sd in cells))
        lines += ['', 'Differences smaller than the ± spread are probably just chance: run more repeats.']
        if errors:
            lines += ['', 'FAILED RUNS:'] + errors
        with open(base + '.txt', 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        self.saved.config(text='Saved: %s.txt / .csv' % os.path.relpath(base, SC.ROOT))

    def open_folder(self):
        d = SC.RUNS
        if not os.path.isdir(d):
            os.makedirs(d)
        if os.name == 'nt':
            os.startfile(d)
        elif sys.platform == 'darwin':
            subprocess.Popen(['open', d])
        else:
            subprocess.Popen(['xdg-open', d])

    # ------------------------------------------------------------------ queue from worker threads
    def poll(self):
        try:
            while True:
                msg = self.q.get_nowait()
                if msg[0] == 'live':
                    _, t, rows = msg
                    self.live_time.config(text='Simulated time %d:%02d' % (t // 60, t % 60))
                    tr = self.live_tree
                    if len(tr.get_children()) != len(rows):
                        tr.delete(*tr.get_children())
                        for r in rows:
                            tr.insert('', 'end', text=r[0], values=r[1:])
                    else:
                        for iid, r in zip(tr.get_children(), rows):
                            tr.item(iid, text=r[0], values=r[1:])
                elif msg[0] == 'live_done':
                    self.live_stop = None
                    self.live_btn.state(['!disabled'])
                    if msg[1] is None:
                        self.live_time.config(text='Live run ended (%s)' % msg[2][:120])
                    else:
                        r = msg[1]
                        self.live_time.config(text='Finished: cars avg time loss %.1f s, people avg wait %.1f s, '
                                                   'collisions %d' % (
                                                       r['car_time_loss'], r['ped_wait_crossings'], r['collisions']))
                elif msg[0] == 'progress':
                    self.prog.config(value=msg[1])
                elif msg[0] == 'cmp_done':
                    self.cmp_stop = None
                    self.go_btn.state(['!disabled'])
                    self.show_results(*msg[1:])
        except queue.Empty:
            pass
        self.root.after(200, self.poll)


def main():
    root = tk.Tk()
    try:
        ttk.Style().theme_use('vista' if os.name == 'nt' else 'clam')
    except tk.TclError:
        pass
    App(root)
    root.mainloop()


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Smart pedestrian crossings on top of the Podu Ros SUMO model (TraCI controller).

Pressure plates count the people waiting at a crossing. The walk signal comes after a countdown
of 25 s minus 2 s per person (min 10 s). In-road sensors watch the cars that turn into the road
behind a "B" crossing: sensor 1 = last 25 m of the shared lane before the turn, sensor 2 / "turn area"
= between the turn and crossing B, sensor 0 = 25-60 m before the turn (used by fix 4).

The rules and constants are the ones from crossing_sim.py. Normally you start this from
smart_gui.py, but it also runs on its own:

  python smart_crossing.py --level aglomerat --minutes 30 --config "{\"smart\": true, \"fix5\": true}"
  python smart_crossing.py --level ora_de_varf --gui            (opens sumo-gui)
"""
from __future__ import print_function
import argparse, collections, json, math, os, sys, time
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from podu_lib import NIVELURI, binary, sumo_home   # noqa: E402

_home = sumo_home()
if _home and os.path.isdir(os.path.join(_home, 'tools')):
    sys.path.append(os.path.join(_home, 'tools'))
import traci                                        # noqa: E402
import traci.constants as tc                        # noqa: E402

NET_ASIS = os.path.join(ROOT, 'retea', 'podu_ros.net.xml')
NET_CTL = os.path.join(ROOT, 'retea', 'podu_ros_ctl.net.xml')   # same net, C4 + C5-east zebras -> signals
SCEN = os.path.join(ROOT, 'scenarii')
RUNS = os.path.join(ROOT, 'rezultate', 'treceri_inteligente')

# =====================================================================
# SETTINGS (same names as crossing_sim.py)
# =====================================================================
COUNTDOWN_START = 25.0      # countdown before anyone is counted (s)
SECONDS_PER_PERSON = 2.0    # countdown gets this much shorter per person (s)
COUNTDOWN_MIN = 10.0        # countdown never goes below this (s)
MIN_CAR_GREEN = 12.0        # cars always get at least this much green between walks (s)
AMBER_TIME = 3.0
ALL_RED_TIME = 1.0
WALK_TIME = 8.0
CLEAR_TIME = 4.0            # flashing walk: finish crossing, nobody new starts
YOUR_RULE_TOTAL_CAP = 60.0  # "60 s total cap": max total wait, from the first person
SHORT_HOLD_CAP = 12.0       # "12 s cap": max hold after the countdown ends

MIN_WALK_B = 5.0            # fix 2: shortest walk phase (s)
SHORT_CLEAR = 1.0           # fix 2: clearance when the crossing is confirmed empty (s)
PAIR_MAX_WAIT = 5.0         # fix 3: B waits for A's walk only if it's due within this (s)
GAP_NEEDED = 2.5            # fix 4: no car on sensor 0 for this long counts as a gap (s)
GAP_MAX_WAIT = 4.0          # fix 4: longest wait for a gap (s)
PULL_A_WITHIN = 15.0        # fix 5: pull A's walk forward if A is due within this (s)
SPILL_RISK_OK = 0.10        # fix 5: walk B only if the chance of spill-back is below this
SMART_MAX_WAIT = 8.0        # fix 5: longest B will wait for a safer moment (s)
TURN_RATE_WINDOW = 180.0    # fix 5: turning rate is learned from the last this-many seconds
TURN_RATE_PRIOR = 0.07      # fix 5: starting guess, turners per second
EMPTY_ROAD_LEN = 60.0       # fix 6: "empty road" = no car this close to the crossing (m)
EMPTY_ROAD_WAIT = 2.0       # fix 6: walk starts this soon after someone steps on the plate (s)
SMART_CLEAR_MIN = 1.0       # fix 7: clearance never shorter than this (s)
SMART_CLEAR_MAX = 10.0      # fix 7: ... or longer than this (s)
MAX_WAIT = 45.0             # fix 8: nobody waits longer than this (s)

DWELL_TIME = 1.0            # must stand on a plate this long to be counted (s)
SENSOR1_LEN = 25.0          # sensor 1 covers this much of the shared lane before the turn (m)
SENSOR0_LEN = 60.0          # sensor 0 covers 25..60 m before the turn (m)
CAR_SPACE = 7.0             # storage per queued car (m)
PED_JAM_TIME = 20           # SUMO: people stuck this long squeeze past (default 300 s; see README)

# =====================================================================
# SETUPS
# =====================================================================
FIXES = collections.OrderedDict([
    ('fix2', "End the walk early when the crossing is empty"),
    ('fix3', "Line up B's walk with A's (B waits up to 5 s)"),
    ('fix4', "Wait for a gap in traffic on sensor 0 (up to 4 s)"),
    ('fix5', "Coordinated, storage-aware: learned turning rate, walk B when spill-back risk < 10 % "
             "(else wait up to 8 s), pull A forward if due within 15 s, end early when empty, "
             "stop new walkers when the turn area is full"),
    ('fix6', "NEW - Empty road, walk now: if no car is within 60 m, skip the countdown"),
    ('fix7', "NEW - Smart clearance: cars stay red until the crossing is really empty (1-10 s) "
             "instead of a fixed 4 s"),
    ('fix8', "NEW - Max wait guarantee: nobody waits more than 45 s; overrides holds and smart waits"),
])
HOLD_MODES = collections.OrderedDict([
    ('none', 'No hold'),
    ('cap60', 'Hold, 60 s total cap'),
    ('cap12', 'Hold, 12 s cap'),
])
DEFAULT_CONFIG = dict(smart=True, hold='cap12', **{k: False for k in FIXES})


def config_label(cfg):
    if not cfg.get('smart', True):
        return 'As-is (original model)'
    fx = [k[3:] for k in FIXES if cfg.get(k)]
    return '%s%s' % (HOLD_MODES[cfg.get('hold', 'cap12')], (' + fix ' + ', '.join(fx)) if fx else '')


# =====================================================================
# SITES (found by analysing the network - see README)
# B = crossing on the road the turners enter, E = edge it crosses, P = crossing position on E,
# shared = (edge, lane) where turning and straight cars share a lane, storage = metres from the
# turn to crossing B (measured as driving distance), A = main-road crossing paired with B.
# =====================================================================
SITES = collections.OrderedDict([
    ('north', dict(label='North: Bd. Regele Ferdinand left turn -> Podu Ros',
                   B=':6413766796_c0', E='1072468318', P=3.3, A=':12043430980_c0',
                   shared=('305379148', 3), storage=12.3)),
    ('nicolina', dict(label='South: roundabout exit -> Str. Nicolina',
                      B=':10616411211_c0', E='305271347', P=68.44, A=':10616411210_c0',
                      shared=('324784651', 1), storage=86.6)),
    ('nationala', dict(label='West: roundabout exit -> Sos. Nationala (C4)',
                       B=':3086446449_c0', E='30959184#0', P=0.1, A=None,
                       shared=('324972230', 1), storage=63.2)),
    ('regele_mihai', dict(label='East: roundabout exit -> Bd. Regele Mihai I (C5)',
                          B=':12080013339_c0', E='22771428#0', P=0.1, A=None,
                          shared=('324784649#0', 1), storage=83.8)),
])
EXTRA = [':12159533179_c0', ':6413766794_c0']     # other crossings on the north signal heads
NAMES = {
    ':6413766796_c0': 'B north - Podu Ros, after Ferdinand left turn',
    ':12043430980_c0': 'A north - Bd. Mangeron',
    ':10616411211_c0': 'B south - Nicolina exit',
    ':10616411210_c0': 'A south - Nicolina entry',
    ':3086446449_c0': 'B west - Sos. Nationala exit (C4)',
    ':12080013339_c0': 'B east - Regele Mihai exit (C5)',
    ':12159533179_c0': 'Podu Ros northbound (C1)',
    ':6413766794_c0': 'Podu Ros (C1)',
}
# north junction: original car phases (average durations measured from the actuated program),
# exclusive all-red pedestrian phase removed because the crossings now run on their own
JOINED_BASE = [(36, 'GGGGGGGGrrrrrGGGGGGGGG'), (3, 'GGGGyyyyrrrrrGGGGGGGGG'),
               (29, 'GGGGrrrrGGGGGGGGGGGGGG'), (3, 'GGGGrrrryyyyyGGGGGGGGG'),
               (3, 'yyyyrrrryyyyyyyyyyyyyy')]
RANK = {'r': 0, 'y': 1, 'g': 2, 'G': 3}
STATE_TEXT = {'GREEN': 'cars go', 'COUNTDOWN': 'countdown', 'SMARTWAIT': 'waiting for safe moment',
              'PAIRWAIT': 'waiting for A', 'GAPWAIT': 'waiting for gap', 'HOLD': 'holding for cars',
              'AMBER': 'amber', 'ALLRED': 'all red', 'WALK': 'WALK', 'CLEAR': 'clearing'}


def countdown_for(n):
    return max(COUNTDOWN_MIN, COUNTDOWN_START - SECONDS_PER_PERSON * n)


def build_ctl_net(log=print):
    """the controlled network = original + signals at C4 and C5-east (they are zebras in the model)"""
    if os.path.isfile(NET_CTL) and os.path.getmtime(NET_CTL) >= os.path.getmtime(NET_ASIS):
        return NET_CTL
    import subprocess
    log('Building retea/podu_ros_ctl.net.xml (one time) ...')
    subprocess.check_call([binary('netconvert'), '-s', NET_ASIS, '--tls.set', '3086446449,12080013339',
                           '--tls.join', 'false', '--no-warnings', '-o', NET_CTL])
    return NET_CTL


class Crossing(object):
    def __init__(self, cid, node, walkingareas):
        self.id, self.node, self.was = cid, node, walkingareas
        self.name = NAMES.get(cid, cid)
        self.state, self.t_state = 'GREEN', 0.0
        self.wait_start, self.last_end = None, -1e9
        self.detected, self.committed, self.short_clear = 0, set(), False
        self.links_ped, self.links_car, self.edges = [], [], []
        self.site = self.partner = self.b_of = None
        self.walkers = 0

    def go(self, s, t):
        self.state, self.t_state = s, t


class Controller(object):
    def __init__(self, config=None):
        self.cfg = dict(DEFAULT_CONFIG)
        self.cfg.update(config or {})
        self.smart = self.cfg.get('smart', True)
        self.t = 0.0
        net = NET_CTL if self.smart else NET_ASIS
        root = ET.parse(net).getroot()
        edges = {e.get('id'): e for e in root.findall('edge')}
        wa = collections.defaultdict(list)
        for e in root.findall('edge'):
            if e.get('function') == 'walkingarea':
                wa[e.get('id')[1:].rsplit('_', 1)[0]].append(e.get('id'))
        self.edge_len = {e.get('id'): float(e.find('lane').get('length'))
                         for e in root.findall('edge') if e.find('lane') is not None}
        ids = [S['B'] for S in SITES.values()] + [S['A'] for S in SITES.values() if S['A']] + EXTRA
        self.cr = collections.OrderedDict()
        for cid in ids:
            node = cid[1:].rsplit('_', 1)[0]
            c = Crossing(cid, node, wa[node])
            for e in edges[cid].get('crossingEdges').split():
                if self._cars_allowed(edges[e]):
                    at_end = edges[e].get('to') == node
                    c.edges.append((e, (self.edge_len[e] - 0.1) if at_end else 0.1, at_end))
            self.cr[cid] = c
        self.sites = collections.OrderedDict()
        for k, S in SITES.items():
            S = dict(S)
            S['cap'] = int(S['storage'] // CAR_SPACE) + 1
            S['turn_log'], S['seen'] = [], set()
            S['area'], S['s1'], S['s0'] = set(), set(), set()
            S['last_s0'] = -1e9
            S['stats'] = collections.Counter()
            self.sites[k] = S
            B = self.cr[S['B']]
            B.site = k
            if S['A']:
                A = self.cr[S['A']]
                B.partner, A.b_of = A, B
        self.ped_wait_start, self.ped_waits = {}, collections.defaultdict(list)
        self.st = collections.Counter()
        self.tls, self.routes, self._near = {}, {}, {}
        self.dt = 0.5

    @staticmethod
    def _cars_allowed(edge):
        for l in edge.findall('lane'):
            a, d = l.get('allow'), l.get('disallow', '')
            if (a is not None and 'passenger' in a.split()) or (a is None and 'passenger' not in d.split()):
                return True
        return False

    # ------------------------------------------------------------------ signals
    def bind_links(self):
        for tls in traci.trafficlight.getIDList():
            links = traci.trafficlight.getControlledLinks(tls)
            mine = False
            for i, lk in enumerate(links):
                if not lk:
                    continue
                inl, outl, _ = lk[0]
                ine, oute = inl.rsplit('_', 1)[0], outl.rsplit('_', 1)[0]
                for c in self.cr.values():
                    if outl == c.id + '_0':
                        c.links_ped.append((tls, i)); mine = True
                    elif any((at_end and ine == e) or (not at_end and oute == e) for e, _, at_end in c.edges):
                        c.links_car.append((tls, i)); mine = True
            if mine:
                self.tls[tls] = len(links)

    def base_state(self, tls):
        n = self.tls[tls]
        if tls.startswith('joined'):
            x = self.t % sum(d for d, _ in JOINED_BASE)
            for d, s in JOINED_BASE:
                if x < d:
                    return list((s + 'r' * n)[:n])
                x -= d
        return ['G'] * n

    def apply_signals(self):
        states = {tls: self.base_state(tls) for tls in self.tls}
        for c in self.cr.values():
            car = {'AMBER': 'y', 'ALLRED': 'r', 'WALK': 'r', 'CLEAR': 'r'}.get(c.state, 'G')
            if car == 'G' and c.walkers:
                car = 'g'                       # someone is still on the crossing: cars yield
            for tls, i in c.links_car:
                if RANK[car] < RANK[states[tls][i]]:
                    states[tls][i] = car
            for tls, i in c.links_ped:
                states[tls][i] = 'G' if c.state == 'WALK' else 'r'
        for tls, s in states.items():
            traci.trafficlight.setRedYellowGreenState(tls, ''.join(s))

    # ------------------------------------------------------------------ sensing
    def route(self, v):
        r = self.routes.get(v)
        if r is None or self.t - r[1] > 20:
            r = (traci.vehicle.getRoute(v), self.t)
            self.routes[v] = r
        return r[0]

    def sense_site(self, S, res):
        E, P = S['E'], S['P']
        sh_edge, sh_idx = S['shared']
        st = S['stats']
        area, s1, s0, stopped = set(), set(), set(), {}
        for v, d in res.items():
            rt = self.route(v)
            lane = d[tc.VAR_LANE_ID]
            edge = lane.rsplit('_', 1)[0]
            dist = None
            if E in rt and (edge not in rt or rt.index(E) >= rt.index(edge)):
                dist = traci.vehicle.getDrivingDistance(v, E, P)
                if dist < -1e9 or dist > S['storage'] + SENSOR0_LEN:
                    dist = None
            if dist is not None:
                if dist <= S['storage']:
                    if dist >= 0:
                        area.add(v)
                        if v not in S['seen']:
                            S['seen'].add(v)
                            S['turn_log'].append(self.t)          # sensor 2 count
                elif dist <= S['storage'] + SENSOR1_LEN:
                    s1.add(v)
                else:
                    s0.add(v)
                if d[tc.VAR_SPEED] < 0.3:
                    stopped[v] = dist
            elif sh_edge in rt and not lane.startswith(':') and \
                    (traci.vehicle.getLaneIndex(v) == sh_idx or edge == sh_edge):
                dd = traci.vehicle.getDrivingDistance(v, sh_edge, self.edge_len.get(sh_edge, 0.2) - 0.05)
                if 0 <= dd <= SENSOR1_LEN:
                    s1.add(v)
                elif SENSOR1_LEN < dd <= SENSOR0_LEN:
                    s0.add(v)
        S['area'], S['s1'], S['s0'] = area, s1, s0
        if s0:
            S['last_s0'] = self.t
        # measurement: straight cars stopped right behind a stopped turner
        for v, d in res.items():
            if d[tc.VAR_SPEED] >= 0.3 or v in stopped or E in self.route(v):
                continue
            L = traci.vehicle.getLeader(v, 25)
            if L and L[0] in stopped:
                st['blocked_s'] += self.dt
        if any(x > S['storage'] for x in stopped.values()) and len(area) >= S['cap'] - 1:
            st['spill_s'] += self.dt
        if len(area) >= S['cap']:
            st['area_full_s'] += self.dt
        st['turners_stopped_s'] += self.dt * sum(1 for x in stopped.values() if x <= S['storage'] + SENSOR1_LEN)

    def road_empty(self, c):
        """fix 6: no car within EMPTY_ROAD_LEN of the crossing on any road it crosses"""
        if c.id in self._near:
            return self._near[c.id]
        res = traci.junction.getContextSubscriptionResults(c.node) or {}
        empty = True
        for v in res:
            rt = self.route(v)
            for e, pos, _ in c.edges:
                if e in rt:
                    d = traci.vehicle.getDrivingDistance(v, e, pos)
                    if -1e9 < d <= EMPTY_ROAD_LEN:
                        empty = False
                        break
            if not empty:
                break
        self._near[c.id] = empty
        return empty

    def count_plates(self, c):
        n, first = 0, None
        for w in c.was:
            for p in traci.edge.getLastStepPersonIDs(w):
                if traci.person.getNextEdge(p) == c.id and traci.person.getSpeed(p) < 0.15:
                    key = (p, c.id)
                    t0 = self.ped_wait_start.setdefault(key, self.t)
                    if self.t - t0 >= DWELL_TIME:
                        n += 1
                        first = t0 if first is None else min(first, t0)
        on = traci.edge.getLastStepPersonIDs(c.id)
        for p in on:
            t0 = self.ped_wait_start.pop((p, c.id), None)
            if t0 is not None:
                self.ped_waits[c.id].append(self.t - t0)
        c.walkers = len(on)
        c.first_wait = first
        return n

    # ------------------------------------------------------------------ the rules
    def go_time(self, c):
        cd = countdown_for(c.detected)
        if self.cfg['fix6'] and self.road_empty(c):
            cd = EMPTY_ROAD_WAIT
            return c.wait_start + cd
        t = max(c.wait_start + cd, c.last_end + MIN_CAR_GREEN)
        if self.cfg['fix8'] and c.first_wait is not None:
            t = min(t, max(c.first_wait + MAX_WAIT, c.last_end + AMBER_TIME))
        return t

    def overdue(self, c):
        return self.cfg['fix8'] and c.first_wait is not None and self.t - c.first_wait >= MAX_WAIT

    def candidates(self, c):
        if c.site is None:
            return set()
        S = self.sites[c.site]
        return S['area'] | S['s1']

    def storage_count(self, c):
        return len(self.sites[c.site]['area'])

    def turn_rate(self, c):
        S = self.sites[c.site]
        recent = sum(1 for x in S['turn_log'] if x > self.t - TURN_RATE_WINDOW)
        return (recent + TURN_RATE_PRIOR * 30.0) / (min(TURN_RATE_WINDOW, self.t) + 30.0)

    def spill_risk(self, c):
        room = self.sites[c.site]['cap'] - self.storage_count(c)
        if room < 0:
            return 1.0
        lam = self.turn_rate(c) * (AMBER_TIME + ALL_RED_TIME + MIN_WALK_B + SHORT_CLEAR + 2.0)
        return 1.0 - sum(math.exp(-lam) * lam ** k / math.factorial(k) for k in range(room + 1))

    def smart_decide(self, B, waited):
        A, t = B.partner, self.t
        if self.overdue(B):
            return True
        if A is not None:
            if A.state in ('AMBER', 'ALLRED'):
                return True
            if A.state == 'GREEN' and A.wait_start is not None:
                if self.go_time(A) - t <= PULL_A_WITHIN:
                    if t >= A.last_end + MIN_CAR_GREEN:
                        self.start_walk(A, join=False)
                        self.sites[B.site]['stats']['merged'] += 1
                        return True
                    if waited < SMART_MAX_WAIT:
                        return False
        if self.spill_risk(B) <= SPILL_RISK_OK:
            return True
        if self.storage_count(B) == 0 and not self.sites[B.site]['s1']:
            return True
        return waited >= SMART_MAX_WAIT

    def start_walk(self, c, join=True):
        if c.wait_start is None:
            c.wait_start = self.t
        c.go('AMBER', self.t)
        self.st['walks'] += 1
        B = c.b_of
        if join and B is not None and (self.cfg['fix3'] or self.cfg['fix5']) \
                and B.state in ('GREEN', 'SMARTWAIT', 'PAIRWAIT') and B.detected > 0:
            if B.wait_start is None:
                B.wait_start = self.t
            if self.cfg['fix5']:
                self.b_check(B)
            elif B.state == 'GREEN':
                self.b_after_pair(B)

    def b_begin(self, B):
        A = B.partner
        if self.cfg['fix5']:
            if self.smart_decide(B, 0.0):
                self.b_check(B)
            else:
                B.go('SMARTWAIT', self.t)
        elif (self.cfg['fix3'] and A is not None and A.state == 'GREEN' and A.wait_start is not None
              and self.go_time(A) - self.t <= PAIR_MAX_WAIT):
            B.go('PAIRWAIT', self.t)
        else:
            self.b_after_pair(B)

    def b_after_pair(self, B):
        if self.cfg['fix4'] and not self.overdue(B):
            B.go('GAPWAIT', self.t)
        else:
            self.b_check(B)

    def b_check(self, B):
        cands = self.candidates(B)
        if self.cfg['hold'] == 'none' or not cands or self.overdue(B):
            B.go('AMBER', self.t)
            return
        B.committed = set(cands)
        B.go('HOLD', self.t)
        self.sites[B.site]['stats']['holds'] += 1

    def hold_done(self, B):
        B.committed &= self.candidates(B)
        if not B.committed or self.overdue(B):
            return True
        if self.cfg['hold'] == 'cap60':
            return self.t - (B.wait_start or B.t_state) >= YOUR_RULE_TOTAL_CAP
        return self.t - B.t_state >= SHORT_HOLD_CAP

    def gap_ok(self, B):
        S = self.sites[B.site]
        return not S['s0'] and self.t - S['last_s0'] >= GAP_NEEDED

    def update(self, c):
        t = self.t
        el = t - c.t_state
        c.detected = self.count_plates(c)
        if c.state == 'GREEN':
            if c.detected > 0:
                if c.wait_start is None:
                    c.wait_start = t
                if t >= self.go_time(c):
                    if c.site is not None:
                        self.b_begin(c)
                    else:
                        self.start_walk(c)
            else:
                c.wait_start = None
        elif c.state == 'SMARTWAIT':
            if self.smart_decide(c, el):
                self.b_check(c)
        elif c.state == 'PAIRWAIT':
            A = c.partner
            if A.state in ('AMBER', 'ALLRED', 'WALK') or el >= PAIR_MAX_WAIT or self.overdue(c):
                self.b_after_pair(c)
        elif c.state == 'GAPWAIT':
            if self.gap_ok(c) or el >= GAP_MAX_WAIT or self.overdue(c):
                self.b_check(c)
        elif c.state == 'HOLD':
            if self.hold_done(c):
                self.sites[c.site]['stats']['hold_time'] += el
                c.go('AMBER', t)
        elif c.state == 'AMBER' and el >= AMBER_TIME:
            c.go('ALLRED', t)
        elif c.state == 'ALLRED' and el >= ALL_RED_TIME:
            c.go('WALK', t)
        elif c.state == 'WALK':
            early = self.cfg['fix2'] or (self.cfg['fix5'] and (c.site is not None or c.b_of is not None))
            empty = c.detected == 0 and c.walkers == 0
            if early and el >= MIN_WALK_B and empty:
                c.short_clear = True
            elif self.cfg['fix5'] and c.site is not None and el >= MIN_WALK_B \
                    and self.storage_count(c) >= self.sites[c.site]['cap']:
                c.short_clear = False
                self.sites[c.site]['stats']['spill_cuts'] += 1
            elif el >= WALK_TIME:
                c.short_clear = False
            else:
                return
            self.st['walk_s'] += el
            c.go('CLEAR', t)
        elif c.state == 'CLEAR':
            if self.cfg['fix7']:
                done = (el >= SMART_CLEAR_MIN and c.walkers == 0) or el >= SMART_CLEAR_MAX
            else:
                done = el >= (SHORT_CLEAR if c.short_clear else CLEAR_TIME)
            if done:
                c.go('GREEN', t)
                c.last_end, c.wait_start = t, None

    # ------------------------------------------------------------------ live view helpers
    def status(self):
        rows = []
        for c in self.cr.values():
            st = c.state
            if st == 'GREEN' and c.wait_start is not None:
                left = max(0.0, self.go_time(c) - self.t)
                txt = 'countdown %.0f s' % left
            else:
                txt = STATE_TEXT.get(st, st)
            extra = ''
            if c.site:
                S = self.sites[c.site]
                extra = 'area %d/%d, s1 %d' % (len(S['area']), S['cap'], len(S['s1']))
            rows.append((c.name, txt, c.detected, c.walkers, extra))
        return rows

    def _poi(self, init=False):
        col = {'GREEN': (0, 200, 0, 255), 'WALK': (255, 255, 255, 255), 'CLEAR': (255, 140, 0, 255),
               'AMBER': (255, 220, 0, 255), 'ALLRED': (255, 0, 0, 255)}
        for c in self.cr.values():
            pid = 'smart_' + c.id
            color = col.get(c.state, (255, 220, 0, 255)) if not (c.state == 'GREEN' and c.wait_start) \
                else (255, 220, 0, 255)
            if init:
                x, y = traci.lane.getShape(c.id + '_0')[0]
                traci.poi.add(pid, x, y, color, poiType=c.name, layer=200, width=3, height=3)
            else:
                traci.poi.setColor(pid, color)

    # ------------------------------------------------------------------ run
    def run(self, level='aglomerat', minutes=70, seed=1, scale=1.0, tag=None, gui=False,
            status_cb=None, stop_flag=None, delay=50):
        end = minutes * 60.0
        net = build_ctl_net() if self.smart else NET_ASIS
        tag = tag or 'run_%d' % int(time.time())
        if not os.path.isdir(RUNS):
            os.makedirs(RUNS)
        stat = os.path.join(RUNS, tag + '.stat.xml')
        cmd = [binary('sumo-gui' if gui else 'sumo'), '-c', os.path.join(SCEN, level + '.sumocfg'),
               '-n', net, '--seed', str(seed), '--scale', str(scale), '--end', str(end),
               '--pedestrian.striping.jamtime', str(PED_JAM_TIME),
               '--no-warnings', '--no-step-log', '--statistic-output', stat,
               '--tripinfo-output', os.path.join(RUNS, tag + '.trip.xml'),
               '--summary-output', os.path.join(RUNS, tag + '.sum.xml')]
        if gui:
            cmd += ['--start', '--quit-on-end', '--delay', str(delay)]
        traci.start(cmd, stdout=open(os.devnull, 'w'))
        try:
            self.dt = traci.simulation.getDeltaT()
            if self.smart:
                self.bind_links()
            for S in self.sites.values():
                traci.junction.subscribeContext(self.cr[S['B']].node, tc.CMD_GET_VEHICLE_VARIABLE,
                                                S['storage'] + SENSOR0_LEN + 20, [tc.VAR_LANE_ID, tc.VAR_SPEED])
            if self.cfg['fix6']:
                for c in self.cr.values():
                    if c.site is None:
                        traci.junction.subscribeContext(c.node, tc.CMD_GET_VEHICLE_VARIABLE,
                                                        EMPTY_ROAD_LEN + 30, [tc.VAR_LANE_ID, tc.VAR_SPEED])
            if gui:
                self._poi(init=True)
            n = 0
            while self.t < end - 1e-6:
                if stop_flag is not None and stop_flag.is_set():
                    break
                traci.simulationStep()
                self.t = traci.simulation.getTime()
                self._near = {}
                for S in self.sites.values():
                    self.sense_site(S, traci.junction.getContextSubscriptionResults(self.cr[S['B']].node) or {})
                if self.smart:
                    for c in self.cr.values():
                        self.update(c)
                    self.apply_signals()
                else:
                    for c in self.cr.values():
                        self.count_plates(c)
                n += 1
                if gui and n % 2 == 0:
                    self._poi()
                if status_cb and n % 2 == 0:
                    status_cb(self.t, self.status())
                if n % 2400 == 0:
                    self.routes = {v: r for v, r in self.routes.items() if self.t - r[1] < 60}
        finally:
            try:
                traci.close()
            except Exception:
                pass
        for (p, cid), t0 in self.ped_wait_start.items():
            if self.t - t0 > DWELL_TIME:
                self.ped_waits[cid].append(self.t - t0)        # still waiting at the end
        return self.summary(stat)

    def summary(self, stat):
        res = collections.OrderedDict()
        try:
            st = ET.parse(stat).getroot()
        except Exception:
            st = None

        def g(tag, a):
            if st is None or st.find(tag) is None or st.find(tag).get(a) is None:
                return float('nan')
            return float(st.find(tag).get(a))
        res['car_time_loss'] = g('vehicleTripStatistics', 'timeLoss')
        res['car_waiting'] = g('vehicleTripStatistics', 'waitingTime')
        res['cars_finished'] = g('vehicleTripStatistics', 'count')
        res['cars_unfinished'] = g('vehicles', 'running') + g('vehicles', 'waiting')
        res['teleports'] = g('teleports', 'total')
        res['collisions'] = g('safety', 'collisions')
        res['ped_time_loss'] = g('pedestrianStatistics', 'timeLoss')
        res['peds_jammed'] = g('persons', 'jammed')
        waits = [w for cid in self.cr for w in self.ped_waits.get(cid, [])]
        res['ped_wait_crossings'] = sum(waits) / len(waits) if waits else 0.0
        res['ped_wait_max'] = max(waits) if waits else 0.0
        res['ped_waited_over_45s'] = sum(1 for w in waits if w > 45.0)
        tot = collections.Counter()
        for S in self.sites.values():
            tot.update(S['stats'])
        res['turners_stopped_s'] = tot['turners_stopped_s']
        res['spill_back_s'] = tot['spill_s']
        res['straight_blocked_s'] = tot['blocked_s']
        res['turn_area_full_s'] = tot['area_full_s']
        res['holds'] = tot['holds']
        res['hold_time_s'] = tot['hold_time']
        res['shared_walks'] = tot['merged']
        res['spill_cuts'] = tot['spill_cuts']
        res['walks'] = self.st['walks']
        res['per_crossing_wait'] = {NAMES.get(c, c): (sum(w) / len(w) if w else 0.0, len(w))
                                    for c, w in self.ped_waits.items()}
        res['per_site'] = {k: dict(S['stats'], turners=len(S['seen'])) for k, S in self.sites.items()}
        return res


# what the comparison table shows, in order: key, label, lower_is_better
METRICS = [
    ('car_time_loss', 'Cars: avg time loss (s)', True),
    ('car_waiting', 'Cars: avg time standing (s)', True),
    ('cars_finished', 'Cars: trips finished', False),
    ('cars_unfinished', 'Cars: still in the network at the end', True),
    ('teleports', 'Cars: teleports (gridlock)', True),
    ('collisions', 'Collisions', True),
    ('ped_wait_crossings', 'People: avg wait at the 8 studied crossings (s)', True),
    ('ped_wait_max', 'People: longest wait (s)', True),
    ('ped_waited_over_45s', 'People: waits over 45 s', True),
    ('ped_time_loss', 'People: avg time loss per trip (s)', True),
    ('peds_jammed', 'People: jammed', True),
    ('turners_stopped_s', 'Turners standing near B crossings (car-s)', True),
    ('spill_back_s', 'Turn-area spill-back (s)', True),
    ('straight_blocked_s', 'Straight cars blocked by a turner (car-s)', True),
    ('turn_area_full_s', 'Turn area full (s)', True),
    ('holds', 'Holds', None),
    ('hold_time_s', 'Hold time (s)', None),
    ('shared_walks', 'Shared A+B walks (fix 5)', None),
    ('spill_cuts', 'Walks cut because turn area full (fix 5)', None),
    ('walks', 'Walk phases', None),
]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--level', default='aglomerat', choices=list(NIVELURI.keys()))
    ap.add_argument('--minutes', type=float, default=70)
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--scale', type=float, default=1.0)
    ap.add_argument('--config', default='{}', help='JSON, e.g. {"smart": true, "hold": "cap12", "fix5": true}')
    ap.add_argument('--gui', action='store_true')
    ap.add_argument('--out', help='write the result as JSON here')
    a = ap.parse_args()
    cfg = json.loads(a.config)
    tag = 'cli_%s_s%d_%d' % (a.level, a.seed, int(time.time()))
    t0 = time.time()
    res = Controller(cfg).run(a.level, a.minutes, a.seed, a.scale, tag=tag, gui=a.gui)
    full = dict(DEFAULT_CONFIG); full.update(cfg)
    res['setup'] = config_label(full)
    res['wall_s'] = round(time.time() - t0, 1)
    if a.out:
        with open(a.out, 'w') as f:
            json.dump(res, f, indent=1)
    else:
        print(json.dumps(res, indent=1))


if __name__ == '__main__':
    main()
